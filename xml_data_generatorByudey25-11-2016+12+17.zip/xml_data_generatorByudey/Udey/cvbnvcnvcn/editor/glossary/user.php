<!Doctype html>
<html>
<head>
<title>Glossary</title>
</head>
<?php include("script.php");  ?>
<?php if (!isset($id) || $id == "") :?>
<body>
<h3>Add New Record</h3>
<form method="POST" action="process.php?add" enctype="multipart/form-data">
<div class="form-group row"> 
    <table>
        <tr>
            <td>Frame Number</td>
            <td><div class="col s4 m4 l4"><input class="form-control" type='text' name='id'/></div></td>
        </tr>
		<tr>
            <td>Module Name</td>
            <td><div class="col s4 m4 l4"><input class="form-control" type='text' name='modulename'/></div></td>
        </tr>
        <tr>
            <td>Issue Description</td>
            <td><textarea class="form-control" name='issuedescription' id='editor1' rows="4" cols="50"></textarea></td>
        </tr>
    </table>
    <input type="submit" class="btn btn-default btn-right brandingbg1" value="Save"/>
</form>
<?php else:?>

    <h3>Update the existing Data :</h3>
    <form method="POST" action="process.php?update" class="row">
        <table>
            <tr>

                <td><div class="col s4 m4 l4"><input class="form-control" type='hidden' name='id' value='<?php echo $user->attributes()->id;?>'/></div></td>
            </tr>
            <tr>
                <td>Module Name</td>
                <td><div class="col s4 m4 l4"><input class="form-control" type='text' name='modulename' value='<?php echo $user->modulename;?>'/></div></td>
            </tr>
            <tr>
                <td>Issue Description</td><td><textarea class="form-control" type='text' id='editor1' name='issuedescription'>
                <?php echo $user->issuedescription; ?>
                </textarea></td>
            </tr>
        </table>
        <input type="submit" class="btn btn-default btn-right brandingbg1" value="Save"/>
    </form>
	</div>

</body>
</html>
<?php endif;?>
<script>
    initSample();
</script>