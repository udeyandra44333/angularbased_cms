
</div>
    </div>

 <footer class="page-footer bluebgextra padding-0">
          <div class="footer-copyright">
         
            © 2014 Copyright Text
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
     
          </div>        
<script>
$(".button-collapse").sideNav();
</script>

</body>
</html>