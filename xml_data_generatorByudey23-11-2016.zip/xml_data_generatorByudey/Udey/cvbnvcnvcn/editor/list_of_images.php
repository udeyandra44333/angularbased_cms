<div class='row'>
<?php
//Path to folder which contains images
$dirname = "../project/images/";
 
//Use glob function to get the files
//Note that we have used " * " inside this function. If you want to get only JPEG or PNG use
//below line and commnent $images variable currently in use
$images = glob($dirname."*");
  
//Display image using foreach loop
foreach($images as $image){
	 $imagelink = $image;
$tokens = explode('/', $imagelink);
$previewspec1 = $tokens[sizeof($tokens)-2];
$previewspec2 = $tokens[sizeof($tokens)-1];
//print the image to browser with anchor tag (Use if you want really :) )
echo '<div class="col s3 m3 l3"><a href="'.$image.'" target="_blank"><img  src="'.$image.'" width="150" height="150" /></a><div class="getUrl">Url: '.$previewspec1.'/'.$previewspec2.'</div></div>';
}
?>
</div>