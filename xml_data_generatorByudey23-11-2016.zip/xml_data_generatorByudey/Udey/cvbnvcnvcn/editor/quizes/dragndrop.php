<?php
if(isset($_POST['dragndrop']))
{
$pageid = $_POST['pageid'];
$itemrange =$_POST['itemrange'];
$itemnumber = range(1, $itemrange);
function quote($itemnumber){
    return sprintf("%s", $itemnumber);
}function dquote($itemnumber){
    return sprintf('"%s"', $itemnumber);
}

$listarray = implode(',',array_map('dquote', $itemnumber));
//echo $itemnumber;
//Quest data
$draggablequest = array($_POST['draggableQuest']);
$dragquestQuote = array_map('quote', $draggablequest);
$stackquestelement = array();
array_push($stackquestelement,$dragquestQuote);
print_r($stackquestelement);
function questionquote($draggablequest){
    return sprintf('%s', $draggablequest);
}
$questionlist = implode(',',array_map('questionquote', $draggablequest));

//Answerlist data
$draggabledata = array($_POST['draggableData']);
$dragdataQuote = array_map('quote', $draggabledata);
$stackelement = array();
array_push($stackelement,$dragdataQuote);
$answerlist = implode(',',$dragdataQuote);
print_r($answerlist);
print_r($dragdataQuote);
$headerdiv = '<!doctype html><html lang="en"><head><title>Drag and drop quiz</title>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/style_dragndrop.css">';
$middlecontent = '<body><div class="col s12 iblue heading1"><p class="white-text center-align  "><b>Fill the blanks with the most appropriate options from the drop-down list.</b></p>
</div><div id="content"><div class="questions"></div>
<div id="cardPile"> </div><div id="cardSlots"> </div><div class="attemptfinish white-text"></div><div class="attemptfinish1"><p>You can attempt only three times.</p></div>
<div id="successMessage"><button class="reset btn" id="resetbt" onClick="init()">Reset</button></div><button class="submit btn" id="submitbt" >Submit</button>
     <div class="showAnswer btn"  id="showAnswer">Show Answer</div> 
</div></body></html>';
$correctAnswerclass = 'correctAnswers';
$visibilityclass = 'visibility';
$absoluteclass = 'position-absolute';
$correctdiv = '"<div class='.$correctAnswerclass.'>"';
$visibilitydiv = '"<div><div class='.$visibilityclass.'>"';
$position_absolute = '"<div class='.$absoluteclass.'>"';
    $dragndropjs = '<script>var correctCards = 0;
$( init );
function init() {
  // Hide the success message
  $("#successMessage").show();
     $(".submit").show();
  $("#successMessage").css( {
    left: "727px",
    bottom: "0px",
    width: 0,
    height: 0
  } );
  // Reset the game
  correctCards = 0;
  $("#cardPile").html( "" );
  $("#cardSlots").html( "" );
  // Create the pile of shuffled cards
  var numbers = [ '.$listarray.' ]; 
   var dragvalues = [ '.$answerlist.' ]; 
//numbers.sort( function() { return Math.random() - .5 } );
  for ( var i=0; i<'.$itemrange.'; i++ ) {
    $("<div>" + numbers[i] + '.$position_absolute.' + dragvalues[i] +"</div></div>").data( "number", numbers[i] ).attr( "id", "card"+numbers[i] ).appendTo( "#cardPile" ).draggable( {
      containment: "#content",
      stack: "#cardPile div",
      cursor: "default",
      revert: true,
    drag:function(){
        $(".ui-draggable").removeClass("cursordefault");
        $(".ui-draggable > div").removeClass("cursordefault");
    }
    } );
   
  }
  // Create the card slots
  var words = [ '.$answerlist.' ]; 
  for ( var i=1; i<='.$itemrange.'; i++ ) {
    $('.$visibilitydiv.'+ words[i-1] + "</div></div>").data( "number", i ).appendTo( "#cardSlots" ).droppable( {
      accept: "#cardPile div",
      hoverClass: "hovered",
      drop: handleCardDrop
    } );
  }
    $(".showAnswer").bind("click",function(){
        $(".nextFrame").removeClass("hide");
        $("#cardSlots").empty();
        $("#cardSlots").css({"z-index":"100"});
        $(this).off("click"); 
          $(this).addClass("disabled");
        $(".attemptfinish1").html("<p>Activity is finished. Go to next frame...</p>"); 
      for ( var i=1; i<='.$itemrange.'; i++ ) {
    $('.$correctdiv.'+ words[i-1] + "</div>").data( "number", i ).appendTo( "#cardSlots" );
  }
    });
}
function handleCardDrop( event, ui ) {
  var slotNumber = $(this).data( "number" );
  var cardNumber = ui.draggable.data( "number" );
  if ( slotNumber == cardNumber ) {
    ui.draggable.addClass( "correctActive" ); 
    ui.draggable.draggable( "disable" );
    $(this).droppable( "disable" );
    ui.draggable.position( { of: $(this), my: "left top", at: "left top" } );
    ui.draggable.draggable( "option", "revert", false );
    correctCards++;
      if ( correctCards == '.$itemrange.' ) {     
          }
  } 
  if ( slotNumber != cardNumber ) {
    ui.draggable.addClass( "wrongActive" );
    ui.draggable.draggable( "disable" );
    $(this).droppable( "disable" );
    ui.draggable.position( { of: $(this), my: "left top", at: "left top" } );
    ui.draggable.draggable( "option", "revert", false );
    correctCards++;
             
  }
  if ( correctCards == '.$itemrange.' ) {
    $("#successMessage").show();
      $(".submit").show();
         
        document.getElementById("submitbt").disabled = false;
       document.getElementById("resetbt").disabled = false;   
  }

};</script>';
$dragndropcss = '<style type="text/css">#cardPile,#content,.questions{left:0}#cardPile,#cardSlots,#cardSlots div,.cursordefault{cursor:default!important}#cardPile div,#cardSlots div{float:left;width:200px;height:46px;padding-top:10px;padding-bottom:10px;border:1px solid #c4c4c4;margin:9px 0 0;position:relative;overflow:hidden;color:#000;font-size:18px;cursor:pointer}#cardPile,#cardSlots{width:240px;height:480px;padding:20px;float:right;position:relative;cursor:pointer}.heading1{position:absolute!important;top:0;width:875px!important;left:0;height:53px;padding-top:0!important;color:#000;text-align:left;z-index:10;padding-left:27px}#content{height:390px;width:875px;margin-left:0;background:#fff;position:relative;top:0;padding-top:15px}.position-icon{background-position:right center!important}.reset,.submit{top:339px;width:150px;background:#1B75BB;color:#fff;font-size:16px;border:1px solid #1B75BB;position:absolute}.submit{right:20px}.reset{right:70px}.wrongActive{display:block;background:url(images/wrong.png) 265px center no-repeat}.correctActive{display:block;background:url(images/correct.png) 265px center no-repeat}#cardSlots{bottom:51px;left:30px}.visibility{visibility:hidden}.attemptfinish1{float:left;position:absolute;bottom:0;left:25px;color:#000}@media screen and (max-width:1024px){#content{width:840px;right:13px}.heading1{width:840px!important;left:79px}.questions div{width:379px}.reset{right:112px}}</style></head>';
$dragndropjs2 = '<script type="text/javascript">      //document.getElementById("submitbt").disabled = true;
     // document.getElementById("resetbt").disabled = true;
  var questionlist = ['.$questionlist.'];
    $(document).ready(function(){
    var arraylist = questionlist.length;
        console.log(arraylist);
        for(var len=0; len< arraylist; len++)
            {
                $(".questions").append("<div></div>");
            }
    $(".questions div").each(function (i) {
 $(this).append(questionlist[i]);
});
         $(".ui-draggable").removeClass("cursordefault");
        $(".ui-draggable > div").removeClass("cursordefault");
	  $(".jp-next").prop("disabled",false);
         $(".timeline-disable").show();
          $(".jp-next").addClass("light-green");
            $(".jp-next").removeClass("grey");
        $(".audio-play_1").addClass("disable-play-icon");
        $(".audio-pause").addClass("disable-pause-icon");
        $(".replay-audio").addClass("disable-replay-icon");
        $(".jp-mute").addClass("disable-mute-icon");
         $(".nextFrame").text("Click/Tap forward arrow to continue"); 
        $(".nextFrame").addClass("hide");
      $(".showAnswer").hide();
     var parent = $("#cardPile");
                var divs = parent.children();
                    while (divs.length) {
                        parent.append(divs.splice(Math.floor(Math.random() * divs.length), 1)[0]);
                    }
        $(".reset").bind("click",function(){
            document.getElementById("submitbt").disabled = true;
            var parent = $("#cardPile");
                var divs = parent.children();
                    while (divs.length) {
                        parent.append(divs.splice(Math.floor(Math.random() * divs.length), 1)[0]);
                    }
            //$(".attemptfinish").empty();
            document.getElementById("resetbt").disabled = true;
        });
        var count=0;
    $(".submit").bind("click",function(){
         document.getElementById("submitbt").disabled = true;
        count++;
        $(".correctActive").addClass("position-icon");
        $(".wrongActive").addClass("position-icon");
         $("#successMessage").show();
         $(".attemptfinish").html("<p class>"+count+"</p>");
  
       if((count==3) && (($( ".correctActive" ).length) < '.$itemrange.'))
            {
               
                $(".reset").off("click"); 
                 $(".submit").off("click");
                  $(".reset").prop("onclick",null).off("click");
                   $(".reset").addClass("disabled");
                    $(".submit").addClass("disabled");
                     $(".showAnswer").show();
                       //$(".attemptfinish1").empty();
               
            }
        else if(($( ".correctActive" ).length) == '.$itemrange.')
      {
          document.getElementById("resetbt").disabled = true;   
            $(".nextFrame").removeClass("hide");
         $(".attemptfinish1").html("<p>Activity is finished. Go to next frame...</p>");  
      }
      $(".ui-draggable").addClass("cursordefault");
$(".ui-draggable > div").addClass("cursordefault");
    });
});</script>';
$finalCompiledData = $headerdiv.''.$dragndropcss.''.$dragndropjs.''.$dragndropjs2.''.$middlecontent;
$quizCreator = fopen('../../project/page'.$pageid.'.html', "w") or die("Unable to open file!");
fwrite($quizCreator, $finalCompiledData);
fclose($quizCreator);
}
?>