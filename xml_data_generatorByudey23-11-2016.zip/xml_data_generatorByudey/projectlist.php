<div class="col s12 m12 l12 padding-0 height-430">
<ul class="collapsible white-text no-border" data-collapsible="accordion">
<?php

include ("dbconnect.php");
    $userfoldername = $userRow['user_name'];
 $select=mysql_query("SELECT * FROM directories WHERE  user_folder LIKE '$userfoldername'");
    
/* Change this configuration in live domain*/
$domain = $_SERVER['SERVER_NAME']."/config/config/xml_data_generatorByudey";
$openText = "open";
  while($userrow=mysql_fetch_array($select))
  {
  $projectname=$userrow['userdirectory'];
  echo "<li><div class='col s12 m12 l12 bof-collapsible-header collapsible-header'><i class='fa fa-pencil-square-o caretini-fontio' aria-hidden='true'></i><div class='col s16 m6 l6 padding-0'>".$projectname."</div><i class='fa fa-caret-down caretino caretini-fontio' aria-hidden='true'></i></div><div class='col s12 m12 l12 collapsible-body border-bottom light-navbg'><a href='http://$domain/$userfoldername/$projectname/editor/process.php?list' class='margin-right-10 projectlink-preview'>".$openText."</a><a href='http://$domain/$userfoldername/$projectname/project/' class='margin-right-10 projectlink-preview' target='_blank'>Preview</a></div></li>";
  }
?>
</ul>
</div>