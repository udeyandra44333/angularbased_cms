<div class="col s12 m12 l12">
<form action="assesment/quizesCreator.php" method="post" enctype="multipart/form-data">
<div class="col s12 m12 l12 padding-0">
   <div class="col s12 m4 l4">
    Page ID
    </div> 
   <div class="col s12 m8 l8">
    <input type="text" name="pageid" placeholder="Enter page id" />
   </div>
</div>
<div class="col s12 m12 l12">
<div class="col s12 m4 l4">
  Question    
</div>
<div class="col s12 m8 l8">
  <textarea name="question" placeholder="Enter Question"> 
    </textarea>
</div>
</div>
<div class="col s12 m12 l12">
<div class="col s12 m4 l4">
Options    
</div> 
<div class="col s12 m8 l8">
   <div class="col s12 m12 l12">
    <div class="col s12 m6 l6">
       <input type="text" name="option1" placeholder="Enter Option1" />
    </div>
    <div class="col s12 m6 l6">
       <input type="text" name="correct1" placeholder="true/false" />
    </div>
    </div>
    <div class="col s12 m12 l12">
    <div class="col s12 m6 l6">
       <input type="text" name="option2" placeholder="Enter Option2" />
    </div>
    <div class="col s12 m6 l6">
       <input type="text" name="correct2" placeholder="true/false" />
    </div>
    </div> 
    <div class="col s12 m12 l12">
    <div class="col s12 m6 l6">
       <input type="text" name="option3" placeholder="Enter Option3" />
    </div>
    <div class="col s12 m6 l6">
       <input type="text" name="correct3" placeholder="true/false" />
    </div>
    </div> 
    <div class="col s12 m12 l12">
    <div class="col s12 m6 l6">
       <input type="text" name="option4" placeholder="Enter Option4" />
    </div>
    <div class="col s12 m6 l6">
       <input type="text" name="correct4" placeholder="true/false" />
    </div>
    </div>
    <div class="col s12 m12 l12">
    <div class="col s12 m6 l6">
       <input type="text" name="option5" placeholder="Enter Option5" />
    </div>
    <div class="col s12 m6 l6">
       <input type="text" name="correct5" placeholder="true/false" />
    </div>
    </div>  
    <div class="col s12 m12 l12">
    <div class="col s12 m6 l6">
       <textarea  name="correctFeedback" placeholder="">
           Enter feedback text
        </textarea>
    </div>
    <div class="col s12 m6 l6">
        <textarea  name="wrongFeedback" placeholder="">
           Enter feedback text
        </textarea>
    </div>
    </div>
    <div class="col s12 m12 l12">
    <div class="col s12 m6 l6">
      Create Quiz
    </div>
    <div class="col s12 m6 l6">
       <input type="submit" name="createQuiz" value="Create Quiz" />
    </div>
    </div> 
</div>
</div>

</form>
</div>

