<?php
if(isset($_POST['coursenmoduleTitle']))
{
    $courseTitle = $_POST['courseTitle'];
    $moduleTitle = $_POST['moduleTitle'];
$openxml = fopen('../project/transcript/course.xml','w') or die("Unable to open file!");
    $courseXml = '<?xml version="1.0"?>
<course><coursetitle>'.$courseTitle.'</coursetitle><moduletitle>'.$moduleTitle.'</moduletitle><course></course>';
     fwrite($openxml, $courseXml);
    fclose($openxml);
    echo "Succesfully Created";
}
?>