<?php


session_start();
include_once '../../../dbconnect.php';

if(!isset($_SESSION['user']))
{
	header("Location: ../../../index.php");
}
$res=mysql_query("SELECT * FROM users WHERE user_id=".$_SESSION['user']);
$userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>XML CRUD APP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <script src="js/jquery-3.1.1.js"></script>
<script src="../../../js/jquery-ui.min.js"></script>
   <!--<script src="../../../js/paging.js"></script>-->
    <script src="ckeditor.js"></script>
	<script src="js/editorsnis.js"></script>
      <!--Let browser know website is optimized for mobile-->
    <script src="../../../js/myauthor.js"></script>
    <script src="js/jscolor.js"></script>
<link rel="stylesheet" href="css/ckeditor.css" />
<link rel="stylesheet" href="../../../css/myauthor.css" />
<link rel="stylesheet" href="../../../css/animate.css" />
    <link rel="stylesheet" type="text/css" href="../../../css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/editor.css" />
<link rel="stylesheet" type="text/css" href="css/materialize.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" />
    <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
    <script src="http://lab.cubiq.org/iscroll5/build/iscroll.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.2.5/ace.js"></script>
    <script type="text/javascript">
$(function(){
    $('.editor').each(function(e){
        CKEDITOR.replace( this.id, { customConfig: '/jblog/ckeditor/config_Large.js' });
    });
});
   
</script>
<style>
.margin-top-60 {
    margin-top: -126px;
}    
</style>
</head>
<body>
   <div id="preloader">
<div class="loader"></div>
    </div>
    <div class="overlay">
    
</div> 
<div class="overlay_bx">
    
</div>
    <div class="content-video-overlay"></div>
<div class="frame-video-overlay"></div>
<div class="quiz-integrate-overlay">
    
</div>
    <div class="tabfeature-overlay">
    
    </div>
    <div class="assesmentCreatorOverlay">
</div>
    <div class="coursenmoduleOverlay">
    
</div>

<div class="dialogbox">
<h5 class="padding-left-10">Uploaded Images</h5>
    <div class="close-iconx"></div>
<div class="imaging">
   <?php include("list_of_images.php");
    ?> 
</div>
</div>
<?php
     include_once '../../../animationlist.php';
    ?>
<div class="row">    
    <div class="col s12 m12 l12 padding-0">
    <div class="col s12 m12 l12 padding-0">
<div class="col s12 m2 l2 padding-0">
 <aside class="col s12 m12 l12 padding-0">
<div class="col s12 m12 l12 padding-0 white-text">
<h5 align="center">Boffin</h5>    
</div>
<div class="col s12 m12 l12 margin-top-30">
<div class="col s12 m4 l4 padding-0">
   <img src="../../../images/icon.png" class="profileimg border-item" /> 
</div>
<div class="col s12 m8 l8 white-text">
<div class="col s12 m12 l12 padding-0">
<span class="welcome">Welcome,</span>
</div>
<div class="col s12 m12 l12 padding-0">
<a href="#" class="profile username"><?php if(!$userRow['user_name']){echo "Guest"; }else{ echo $userRow['user_name']; } ?></a>    
</div>
</div>
     </div>
<div class="col s12 m12 l12 margin-top-12">
  <h6  class="white-text"><i class="fa fa-list caretini-fontio listino" aria-hidden="true"></i> List of projects</h6>	   
</div>		
<?php
include("../../../projectlist.php");
?>

		
	</aside>   
</div>
<div class="col s12 m10 l10 loadeditor padding-0">

<?php
    include_once '../../../subheader.php';
    /*Need to change during live*/
    $url = $_SERVER['REQUEST_URI'];
$tokens = explode('/', $url);
$previewspec = $tokens[sizeof($tokens)-3];
    ?>
    <!--<ul>
        <li><a href="process.php?list">List Pages</a></li>
        <li><a href="process.php?add">Add Pages</a></li>
    </ul>  -->
     <nav class="height-50">
    <div class="nav-wrapper brandingbg1">
      <ul id="nav-mobile" class="left hide-on-med-and-down margin-top-21 tablistmgr">
           <?php
   echo "<li><a href='http://$domain' class='hovmenu'><span class='movetextup'>Go Back</span></a></li>";
       ?>
        <li><a href="process.php?list" class="hovmenu"><span class="movetextup">Page List</span></a></li>
        <li><a href="process.php?add" class="hovmenu"><span class="movetextup">Add Page</span></a></li>
          <li><a href="#" id="customui" class="hovmenu"><span class="movetextup">Customize UI</span></a></li>
        <li class="glsry"><a href="#" class="hovmenu dropdown1"><span class="movetextup">Create Glossary</span></a>
          <ul class="brandingbg1">
            <li><a href="#" class="coursenmoduleTitle nestedanchor">Course Title</a></li>
            <li><a href="#" class="glossarylist nestedanchor"  onclick="window.open('glossary/process.php?list', 'MsgWindow', 'width=1024,height=640');">Show glossary</a></li>
              <li><a href="#" class="addglossary nestedanchor" onclick="window.open('glossary/process.php?add', 'MsgWindow', 'width=1024,height=640');">Create glossary</a></li>
            </ul>
          </li>
        <li><a href="#" class="listofimages hovmenu"><span class="movetextup">Show Images</span></a></li>
        <li><a href="#" id="animationlist" class="hovmenu"><span class="movetextup">Animation list</span></a></li>
        <li class="glsry"><a href="#" id="quizes" class="hovmenu dropdown2"><span class="movetextup">Features</span></a>
          <ul class="brandingbg1">
              <li><a href="#" class="tabfeature nestedanchor">Tab Feature</a></li>
            <li><a href="#" class="singlechoice nestedanchor">Quiz</a></li>
              <li><a href="#" class="assesment nestedanchor">Assesment</a></li>
            </ul>
          </li>
          <li class="glsry"><a href="#" class="hovmenu dropdown3"><span class="movetextup">Video</span></a>
          <ul class="brandingbg1">
            <li><a href="#" class="contentVideo nestedanchor">Content Video</a></li>
            <li><a href="#" class="frameVideo nestedanchor">Frame Video</a></li>
            </ul>
          </li>
        <li><?php echo "<a href='http://$domain/$userfoldername/$previewspec/project' target='_blank' class='hovmenu'><span class='movetextup'>Preview</span></a>" ?></li>
      </ul>
    </div>
  </nav>

     <div class="uicustom">
    <div class="headersection">
         <h5 class="modalheader">Customize your player</h5>
        <div class="close-icon"></div>
         </div>
    <div class="uicust-body">
<div class="col s12 m12 l12  padding-0">
     <div class="col s12 m6 l6 padding-0">
         <div class="col s12 m12 l12 ">
        <form action="uploadlogo.php" name="imageUpload" method="POST" id="imageUpload" target="imageUploads" enctype="multipart/form-data" >
        <fieldset>
            <legend>Logo File:</legend>
         <input type="file" name="image" id="imageUpload"  />
         <input type="submit"  />
        </fieldset>
      </form>
    </div>
    </div>  
    <div class="col s12 m6 l6 padding-0">
    <div class="col s12 m12 l12">
        <form action="homescreen.php" method="POST" target="homescreenUpload" id="launchscreenform" enctype="multipart/form-data">
        <fieldset>
<legend>Homescreen File:</legend>
         <input type="file" name="image" />
         <input type="submit"/>
        </fieldset>
      </form>
    </div>   
    </div>
</div>
<form action="header-footercss.php" method="post" enctype="multipart/form-data">
        <div class="col s12 m6 l6  padding-0">
           <div class="col s12 m12 l12">
        <fieldset>
        <legend>Player Header/Footer</legend>
           <label>Header/Footer Bg
         <input class="jscolor" name="bgcolor1" value="transparent">
            </label> 
        <label>Header/Footer Text Color
         <input class="jscolor" name="headertextcolor" value="transparent">
            </label>
        <label>Frame/Section name color
         <input class="jscolor" name="framesectioncolor" value="transparent">
            </label>
            </fieldset>
        </div>
        <div class="col s12 m12 l12">
        <fieldset>
         <legend>Timeline</legend>
              <label>Timeline color
         <input class="jscolor" name="timeline" value="transparent">
            </label>
        <label>Progressbar color
         <input class="jscolor" name="timelinecolor" value="transparent">
            </label>
            </fieldset>
        </div>   
        <div class="col s12 m12 l12">
        <fieldset>
         <legend>Frame Container</legend>
              <label>Add Background
         <input class="jscolor" name="framebg" value="transparent">
            </label>  
        <label>Add frame text color
         <input class="jscolor" name="frametext" value="transparent">
            </label>
            </fieldset>
        </div>  
        <div class="col s12 m12 l12">
        <fieldset>
         <legend>Glossary</legend>
              <label>Add Background
         <input class="jscolor" name="glossarybg" value="transparent">
            </label>  
        <label>Add text color
         <input class="jscolor" name="glossarytext" value="transparent">
            </label>
            </fieldset>
        </div>
        </div>
        <div class="col s12 m6 l6  padding-0">
              <div class="col s12 m12 l12">
        <fieldset>
        <legend>Menu Background</legend>
            <label>
            Menu Bg
            <input class="jscolor" name="menuboxbg" value="transparent" />
            </label> 
            <label>
            Menu icons color
            <input class="jscolor" name="iconcolor" value="transparent" />
            </label> 
            <label>
            Dropdown Menu Item Text color
            <input class="jscolor" name="menuitemtext" value="transparent" />
            </label>
            <label>
            Dropdown Menu Title text
            <input class="jscolor" name="title_menu_text" value="transparent" />
            </label>
            <label>
            Dropdown Menu Title BG
            <input class="jscolor" name="title_menu_bg" value="transparent" />
            </label>
            </fieldset>       
        </div>
        <div class="col s12 m12 l12">
        <fieldset>
            <legend>Transcript</legend>
            <label>Transcript Background
         <input class="jscolor" name="audiotranscriptbg" value="transparent">
            </label>
        <label>
            Transcript Title Text Color
            <input class="jscolor" name="transcript_title_color" value="transparent">
            </label>
        <label>
            Transcript Text
            <input class="jscolor" name="transcript_text" value="transparent">
            </label>
            </fieldset>
            </div>
        </div>
    <div class="col s12 m12 l12">
    <input type="submit" name="css-upload" />           
    </div>       
      </form>
         </div>
    </div>
<div class="content-video white">
<h5 class="padding-left-6">Content Videos</h5>
<div class="closeit"></div>
    <div class="row">
    <div class="col s12 m12 l12">
    <?php include("content-video.php"); ?>    
    </div>
    </div>
</div>

<div class="frame-video white">
<h5 class="padding-left-6">Frame Videos</h5>
    <div class="closeit"></div>
    <div class="row">
    <div class="col s12 m12 l12">
    <?php include("frame-video.php"); ?>    
    </div>
    </div>
</div>

<div class="quiz-integrate white">
<h5 class="padding-left-10">Single choice Quiz</h5>
    <div class="closeit"></div>
<div class="row">
<div class="col s12 m12 l12">
<div class="col s12 m12 l12">
<div class="col s6 m4 l4 padding-0">
<a href="#" class="brandingbg1 btn singlechoiceshow">Single/Multiple Choice</a>    
</div>
<div class="col s6 m4 l4 ">
  <a href="#" class="brandingbg1 btn dragndropshow">Drag and Drop</a>      
</div>
</div>
    <div class="col s12 m12 l12 singlechoice singlechoicequiz">
    <?php
    include("quizes/singleandmultiplechoice.php");
    ?>
    </div>
    <div class="col s12 m12 l12 dragndrop dragndropquiz">
    <h6>Create drag and drop</h6>
    <div class="col s12 m12 l12">
        <form action="quizes/dragndrop.php" method="post" enctype="multipart/form-data">
        <input type="text" name="pageid" placeholder="Enter your PageID" />
        <input type="text" name="itemrange" placeholder="Define number of items" />
        <textarea name="draggableQuest">Question1,Question2 and so on</textarea>
        <textarea name="draggableData">Answer1,Answer2 and so on</textarea>
            <input type="submit" name="dragndrop" value="Create" class="btn large" />
        </form>
    </div>
    </div>
</div>    
</div>    
</div>

<div class="integrate-tabfeature white">
<h5 class="padding-left-10">Tab Feature</h5>
<div class="closeit"></div>
<div class="col s12 m12 l12">
<form action="tabfeature/tabFeature.php" method="post" enctype="multipart/form-data">
<div class="col s4 m4 l4">
    <input type="text" placeholder="Page ID" name="pageid" />
</div>
<div class="col s4 m4 l4">
    <input type="text" placeholder="Tab1" name="tab1" />
    </div>
<div class="col s4 m4 l4">
    <input type="text" placeholder="Tab2" name="tab2" />
    </div>
<div class="col s4 m4 l4">
    <input type="text" placeholder="Tab3" name="tab3" />
    </div>
<div class="col s4 m4 l4">
    <input type="text" placeholder="Tab4" name="tab4" />
    </div>
    <div class="col s12 m12 l12"><textarea class="editor" id="editor5" name="tab_one_content"></textarea></div>
    <div class="col s12 m12 l12"><textarea class="editor" id="editor6" name="tab_two_content"></textarea></div>
    <div class="col s12 m12 l12"><textarea class="editor" id="editor7" name="tab_three_content"></textarea></div>
    <div class="col s12 m12 l12"><textarea class="editor" id="editor8" name="tab_four_content"></textarea></div>
    <input type="submit" name="createtabs" value="Create Tab" />
</form>   
</div>
</div>
    
<div class="assesmentCreator white">
<h5 class="padding-left-10">Create your assesment</h5>
    <div class="closeit"></div>
<div class="col s12 m12 l12">
<?php include("assesment/singleandmultiplechoice.php"); ?>   
</div>
</div>

<div class="coursenmodule white">
<h6>Add Course and Module Title</h6>
<div class="closeit"></div>
<div class="col s12 m12 l12">
<form action="coursenmoduleTitle.php" method="post" enctype="multipart/form-data">
    <input type="text" name="courseTitle" placeholder="Course Title" />    
    <input type="text" name="moduleTitle" placeholder="Module Title" /> 
    <input type="submit" name="coursenmoduleTitle" value="Create" />
</form>    
</div>
</div>
<div class="validationMessage animated fadeInDown">
    <div class="closeit"></div>
 <iframe width="100%" height="25" frameborder="0" scrolling="no" name="imageUploads"  class="logoUpload"></iframe> 
<iframe width="100%" height="25" frameborder="0" scrolling="no" name="homescreenUpload"  class="homescreenUpload"></iframe>
</div>
    <script>
	initSample();
</script>
   
     <script type="text/javascript" src="js/materialize.min.js"></script>
</body>
 

</html>







