<?php
session_start();
if(isset($_SESSION['user'])!="")
{
	header("Location: home.php");
}
include_once 'dbconnect.php';

if(isset($_POST['btn-signup']))
{
	$uname = mysql_real_escape_string($_POST['uname']);
	$email = mysql_real_escape_string($_POST['email']);
	$upass = md5(mysql_real_escape_string($_POST['pass']));
	$ucountry = md5(mysql_real_escape_string($_POST['country']));
	$umobile = md5(mysql_real_escape_string($_POST['mobile']));
	
	$uname = trim($uname);
	$email = trim($email);
	$upass = trim($upass);
	$ucountry = trim($ucountry);
	$umobile = trim($umobile);
	
	// email exist or not
	$query = "SELECT user_email FROM users WHERE user_email='$email'";
	$result = mysql_query($query);
	
	$count = mysql_num_rows($result); // if email not found then register
	
	if($count == 0){
		
		if(mysql_query("INSERT INTO users(user_name,user_email,user_pass,country,mobile) VALUES('$uname','$email','$upass','$ucountry','$mobile')"))
		{
			?>
			<script>alert('successfully registered ');</script>
			<?php
           
mkdir("$uname");
		}
		else
		{
			?>
			<script>alert('error while registering you...');</script>
			<?php
		}		
	}
	else{
			?>
			<script>alert('Sorry Email ID already taken ...');</script>
			<?php
	}
	
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registeration</title>
  <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/materialize.css" />
<link rel="stylesheet" type="text/css" href="css/index.css" />
<link rel="stylesheet" type="text/css" href="css/myauthor.css" />
<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="js/materialize.js"></script>
<style type="text/css">
body{overflow-y:auto;}
</style>
</head>
<body class="login">
<div class="login_wrapper">

        <div class="login-form">
        <div class="login_content">
            <form method="post">
            <h1>Register Form</h1>
            <div>
             <input type="text" class="white" name="uname" placeholder="User Name" required />
            </div>
             <input type="email" class="white"  name="email" placeholder="Your Email" required />
             <input type="password" class="white" name="pass" placeholder="Your Password" required />
             <input type="text"class="white" name="country" placeholder="Country" />
             <input type="text" class="white" name="mobile" placeholder="Tel:"  />
            <div class="card-action border-0 padding-0">
            <a  href="index.php" class="left">Sign In Here</a>
            <button  type="submit" name="btn-signup" class="right btns btn-defaults">Sign Up</button>
            </div>
             <div class="separator">
   

                <div class="clearfix"></div>
                <br>

                <div>
                  <h1>Boffin !</h1>
                  <p>©2016 All Rights Reserved. Boffin !. Privacy and Terms</p>
                </div>   
                </form>
            </div>
        </div>    
</div> 
</div>  
</body>
</html>