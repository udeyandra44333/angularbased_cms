<?php
if(isset($_POST['btn-upload']))
{  
    $pageid = $_POST['pageid'];
    $pagecontent = $_POST['framecontent'];
$myfile = fopen('page'.$pageid.'.html', "w") or die("Unable to open file!");
$txt = "<!DOCTYPE html><html><head><title>Page</title></head><body>".$pagecontent."</body></html>";
fwrite($myfile, $txt);
//$txt = "<!DOCTYPE html><html><head><title>Page</title></head><body>".$pagecontent."</body></html>";
//fwrite($myfile, $txt);
fclose($myfile);
echo "Hey great you done it";
}
?>