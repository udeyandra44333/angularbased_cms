$(document).ready(function(){
   $( "div" ).focus(function() {
 alert(2);
});
});