<?php
session_start();
include_once 'dbconnect.php';

if(isset($_SESSION['user'])!="")
{
	header("Location: home.php");
}

if(isset($_POST['btn-login']))
{
	$email = mysql_real_escape_string($_POST['email']);
	$upass = mysql_real_escape_string($_POST['pass']);
	
	$email = trim($email);
	$upass = trim($upass);
	
	$res=mysql_query("SELECT user_id, user_name, user_pass FROM users WHERE user_email='$email'");
	$row=mysql_fetch_array($res);
	
	$count = mysql_num_rows($res); // if uname/pass correct it returns must be 1 row
	
	if($count == 1 && $row['user_pass']==md5($upass))
	{
		$_SESSION['user'] = $row['user_id'];
    
		header("Location: home.php");
	}
	else
	{
		?>
        <script>alert('Username / Password Seems Wrong !');</script>
        <?php
	}
	
}
?>

<?php 
  include("header.php");  
?>

<div class="login_wrapper">

        <div class="login-form">
        <div class="login_content">
            <form method="post">
            <h1>Login Form</h1>
            <div>
             <input type="text" name="email" placeholder="Your Email" class="white" required />
            </div>
             <input type="password" name="pass" placeholder="Your Password" class="white" required /> 
        
            <div class="card-action border-0 padding-0">
            <a  href="register.php" class="left">Sign Up Here</a>
            <button  type="submit" name="btn-login" class="right btns btn-defaults">Sign In</button>
            </div>
             <div class="separator">
                 <p class="change_link">New to site?
                  <a href="register.php" class="to_register"> Create Account </a>
                </p>

                <div class="clearfix"></div>
                <br>

                <div>
                  <h1>Boffin !</h1>
                  <p>©2016 All Rights Reserved. Boffin !. Privacy and Terms</p>
                </div>   
                </form>
            </div>
        </div>    
</div>


            

<!--<div class="row">
<div class="col s12 m12 l12 margin-bottom-63">
     <div class="col s12 m4 l4 white padding-0">
        <video preload="auto" controls class="col s12 m12 l12 sliderheight">
            <source src="coropratevideo/1.mp4" type="video/mp4" />
        </video>
    </div>
    <div class="col s12 m8 l8 bluebgmid sliderheight padding-0">
        
    </div> 
    </div>
</div>-->


    <link rel="stylesheet" type="text/css"  href="css/index.css" />
<!--https://colorlib.com/wp/free-bootstrap-admin-dashboard-templates/-->