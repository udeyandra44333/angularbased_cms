<div class="slidemenu brandingbg1">
    <div class="row">
    <div class="col s6 m6 l6">
    <h6>Effect List</h6>    
    </div>
    <div class="col s6 m6 l6">
        <a href="#" class="closemenu"></a>
    </div>
    </div>
     <ul class="collapsible box-shadow-0 effectlist brandingbg1 no-border" data-collapsible="accordion">
    <li>
      <div class="collapsible-header brandingbg1 no-border">Fade In</div>
      <div class="collapsible-body addheight-65">
          <div class="row">
              <div class="col s12 m12 l12 animated infinite fadeIn effect white">fadeIn</div>
              <div class="col s12 m12 l12 white-text">Effect Name : fadeIn</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header brandingbg1 no-border">Fade In Down</div>
      <div class="collapsible-body addheight-65">
          <div class="row">
              <div class="col s12 m12 l12 animated infinite fadeInDown effect white">fadeIn Down</div>
              <div class="col s12 m12 l12 white-text">Effect Name : fadeInDown</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header brandingbg1 no-border">FadeIn Left</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite fadeInLeft effect white">fadeIn Left</div>
              <div class="col s12 m12 l12 white-text">Effect Name : fadeInLeft</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header brandingbg1 no-border">FadeIn Right</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite fadeInRight effect white">fadeIn Right</div>
              <div class="col s12 m12 l12 white-text">Effect Name : fadeInRight</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header brandingbg1 no-border">FadeIn Up</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite fadeInUp effect white">fadeIn Up</div>
              <div class="col s12 m12 l12 white-text">Effect Name : fadeInUp</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header brandingbg1 no-border">Flip In X</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite flipInX effect white">Flip In X</div>
              <div class="col s12 m12 l12 white-text">Effect Name : flipInX</div>
          </div>
        </div>
    </li>    
    <li>
      <div class="collapsible-header brandingbg1 no-border">Flip In Y</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite flipInY effect white">Flip In Y</div>
              <div class="col s12 m12 l12 white-text">Effect Name : flipInY</div>
          </div>
        </div>
    </li> 
    <li>
      <div class="collapsible-header brandingbg1 no-border">Light Speed In</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite lightSpeedIn effect white">Light Speed In</div>
              <div class="col s12 m12 l12 white-text">Effect Name : lightSpeedIn</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header brandingbg1 no-border">Slide In Up</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite slideInUp effect white">Slide In Up</div>
              <div class="col s12 m12 l12 white-text">Effect Name : slideInUp</div>
          </div>
        </div>
    </li> 
    <li>
      <div class="collapsible-header brandingbg1 no-border">Slide In Left</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite slideInLeft effect white">Slide In Left</div>
              <div class="col s12 m12 l12 white-text">Effect Name : slideInLeft</div>
          </div>
        </div>
    </li>   
     <li>
      <div class="collapsible-header brandingbg1 no-border">Slide In Right</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite slideInRight effect white">Slide In Right</div>
              <div class="col s12 m12 l12 white-text">Effect Name : slideInRight</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header brandingbg1 no-border">Slide In Down</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite slideInDown effect white">Slide In Down</div>
              <div class="col s12 m12 l12 white-text">Effect Name : slideInDown</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header brandingbg1 no-border">Zoom In</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite zoomIn effect white">Zoom In</div>
              <div class="col s12 m12 l12 white-text">Effect Name : zoomIn</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header brandingbg1 no-border">Zoom In Down</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite zoomInDown effect white">Zoom In Down</div>
              <div class="col s12 m12 l12 white-text">Effect Name : zoomInDown</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header brandingbg1 no-border">Zoom In Up</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite zoomInDown effect white">Zoom In Up</div>
              <div class="col s12 m12 l12 white-text">Effect Name : zoomInDown</div>
          </div>
        </div>
    </li>
  </ul> 
</div>