<?php
if(isset($_POST['insertCss']))
{  
   
    $csscontent = $_POST['addcssCode'];
$cssfile = fopen('../project/css/common.css', "w") or die("Unable to open file!");
$css = $csscontent;
fwrite($cssfile, $css);
//$txt = "<!DOCTYPE html><html><head><title>Page</title></head><body>".$pagecontent."</body></html>";
//fwrite($myfile, $txt);
fclose($cssfile);
echo "Hey great you done it";
}

?>