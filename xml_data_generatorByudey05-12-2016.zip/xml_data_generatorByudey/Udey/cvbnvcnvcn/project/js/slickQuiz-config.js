var quizJSON = {
    "info": {
        "name":    "<b>Learning Activity </b>",
        "main":    "<p><b>Choose the best response and click/tap the Submit button.</b></p>",
        "results": "<h3>Finished</h3><h2>Congratulations you have completed the test.</h2>",
        "level1":  "Excellent",
        "level2":  "Brilliant",
        "level3":  "Good",
        "level4":  "Average",
        "level5":  "Poor" // no comma here
    },
    "questions": [
        { // Question 1 - Multiple Choice, Single True Answer
            "q": " 
    ",
            "a": [
                {"option": "",      "correct": },
                {"option": "",     "correct": },
                {"option": "",      "correct": },
                {"option": "",     "correct": },
                {"option": "",     "correct": }
            ],
            "correct": "<p><span>           Enter feedback text
        </span></p>",
            "incorrect": "<p>           Enter feedback text
        </p>" 
        }
       
      
    ]
};