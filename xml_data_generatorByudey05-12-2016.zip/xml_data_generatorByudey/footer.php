

 <footer class="page-footer bluebgextra padding-0">
          <div class="footer-copyright lightblack padding-5">
              <div class="row">
         <div class="col s12 m12 l12">© 2014 Copyright Text <a class="lightblack right" href="#!">More Links</a></div>
     </div>
          </div>        
  
</body>
</html>