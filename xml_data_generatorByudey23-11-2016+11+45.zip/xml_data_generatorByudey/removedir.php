<?php
$removedir = $_POST['directoryname'];

if (is_dir($removedir)) {
    rmdir($removedir);
}
else{
    
    echo "There is no such directory";
}

?>