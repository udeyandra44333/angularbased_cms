<?php if (!isset($id) || $id == "") :?>
<!Doctype html>
<html>
<head>
<title>Glossary</title>

</head>
<body>
<h3>Add New Record</h3>
<form method="POST" action="process.php?add" enctype="multipart/form-data">
<div class="form-group"> 
    <table>
        <tr>
            <td>Frame Number</td>
            <td><input class="form-control" type='text' name='id'/></td>
        </tr>
		<tr>
            <td>Module Name</td>
            <td><input class="form-control" type='text' name='modulename'/></td>
        </tr>
        <tr>
            <td>Issue Description</td>
            <td><textarea class="form-control" name='issuedescription' id='editor4' rows="4" cols="50"></textarea></td>
        </tr>
    </table>
    <input type="submit" class="btn btn-default" value="Save"/>
</form>
<?php else:?>

    <h3>Update the existing Data :</h3>
    <form method="POST" action="process.php?update">
        <table>
            <tr>

                <td><input class="form-control" type='hidden' name='id' value='<?php echo $user->attributes()->id;?>'/></td>
            </tr>
            <tr>
                <td>Module Name</td>
                <td><input class="form-control" type='text' name='modulename' value='<?php echo $user->modulename;?>'/></td>
            </tr>
            <tr>
                <td>Issue Description</td><td><textarea class="form-control" type='text' id='editor4' name='issuedescription'>
                <?php echo $user->issuedescription; ?>
                </textarea></td>
            </tr>
        </table>
        <input type="submit" class="btn btn-default" value="Save"/>
    </form>
	</div>

</body>
</html>
<?php endif;?>
<script>
    
	initSample();
</script>