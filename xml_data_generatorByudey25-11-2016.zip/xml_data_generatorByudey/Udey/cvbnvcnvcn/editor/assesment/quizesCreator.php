<?php
if(isset($_POST['createQuiz']))
{ 
$comma = ',';
$pageid = $_POST['pageid'];
$question = $_POST['question'];
$option1 = $_POST['option1'];
$option2 = $_POST['option2'];
$option3 = $_POST['option3'];
$option4 = $_POST['option4'];
$option5 = $_POST['option5'];
$answer1 = $_POST['correct1'];
$answer2 = $_POST['correct2'];
$answer3 = $_POST['correct3'];
$answer4 = $_POST['correct4'];
$answer5 = $_POST['correct5'];
$correctFeedback = $_POST['correctFeedback'];
$wrongFeedback = $_POST['wrongFeedback'];
$quizCreator = fopen('assesment/js/slickQuiz-config'.$pageid.'.js', "w") or die("Unable to open file!");
$quizContent = 'var quizJSON = {
    "info": {
        "name":    "<b>Learning Activity </b>",
        "main":    "<p><b>Choose the best response and click/tap the Submit button.</b></p>",
        "results": "<h3>Finished</h3><h2>Congratulations you have completed the test.</h2>",
        "level1":  "Excellent",
        "level2":  "Brilliant",
        "level3":  "Good",
        "level4":  "Average",
        "level5":  "Poor" // no comma here
    },
    "questions": [
        { 
        "q":"'.rtrim($question).'",
            "a": [
                {"option": "'.$option1.'",      "correct": '.$answer1.'},
                {"option": "'.$option2.'",     "correct": '.$answer2.'},
                {"option": "'.$option3.'",      "correct": '.$answer3.'},
                {"option": "'.$option4.'",     "correct": '.$answer4.'},
                {"option": "'.$option5.'",     "correct": '.$answer5.'}
            ],
            "correct": "<p><span>'.$correctFeedback.'</span></p>",
            "incorrect": "<p>'.$wrongFeedback.'</p>" 
        }
       
      
    ]
};';
fwrite($quizCreator, $quizContent);
fclose($quizCreator);
$quizPageCreator = fopen('assesment/page'.$pageid.'.html', "w") or die("Unable to open file!");
$addQuizPage = '<!DOCTYPE html><html><head><meta charset=utf-8><meta content="IE=edge,chrome=1"http-equiv=X-UA-Compatible><meta content="IE=9, IE=10, IE=11"http-equiv=X-UA-Compatible><meta content="IE=EmulateIE9"http-equiv=X-UA-Compatible><meta content="IE=EmulateIE10"http-equiv=X-UA-Compatible><meta content="IE=EmulateIE11"http-equiv=X-UA-Compatible><title>Page '.$pageid.'</title></head><body><div id=slickQuiz><h1 class=quizName></h1><div class=quizArea><div class=quizHeader><a class="button startQuiz waves-effect"href=#>Get Started!</a></div><div class=messagearea></div></div><div class=quizResults><h3 class=quizScore>You Scored: <span></span></h3><h3 class=quizLevel><strong>Ranking:</strong> <span></span></h3><div class=quizResultsCopy></div></div></div><script src=js/slickQuiz-config'.$pageid.'.js></script><script src=js/slickQuiz.js></script><script src=js/master.js></script></body></html>';

    fwrite($quizPageCreator, $addQuizPage);
    fclose($quizPageCreator);
    echo "Quiz Created Successfully";
    }

?>