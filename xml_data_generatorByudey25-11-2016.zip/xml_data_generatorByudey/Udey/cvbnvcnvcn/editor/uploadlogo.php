<style>
    .white-text{color: #fff;}
</style>
<?php
   if(isset($_FILES['image'])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
     // $expensions= array("jpeg","jpg","png");
     $expensions= array("png");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="<p class='white-text'>extension not allowed, please choose a PNG file.</p>";
      }
      
      if($file_size > 4097152){
         $errors[]='<p class="white-text">File size must be excately 2 MB</p>';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"../project/images/".$file_name);
          rename ("../project/images/".$file_name, "../project/images/logo.png");
         echo "<p class='white-text'>File uploaded successfully.</p>";
      }else{
         //print_r($errors);
         print_r("<p class='white-text'>Please select a file</p>");
      }
   }
?>