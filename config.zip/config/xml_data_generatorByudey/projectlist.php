<?php
 $select=mysql_query("SELECT * FROM directories");
  while($userrow=mysql_fetch_array($select))
  
  {
  $projectname=$userrow['userdirectory'];
?>