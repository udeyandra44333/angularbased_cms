<?php
include ("dbconnect.php");
 $select=mysql_query("SELECT * FROM directories");
$userfoldername = $userRow['user_name'];
  while($userrow=mysql_fetch_array($select))
  
  {
  $projectname=$userrow['userdirectory'];
  echo "<ul><li><a href='$userfoldername/$projectname/editor/'>".$projectname."</a></li></ul>";
  }
?>