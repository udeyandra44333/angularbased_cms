
<?php if (!isset($id) || $id == "") :?>
<div class="row">
    <div class="col s12 m8 l8">
 <h3>Add New Record</h3>
<form method="POST" action="process.php?add">
    <table>
        <tr>
            <td>Page ID</td>
            <td><input type='text' name='id'/></td>
        </tr>
        <tr>
            <td>Frame Name</td>
            <td><input type="text"  name='framename' /></td>
        </tr>
        <tr>
            <td>Section Name</td>
            <td><input type="text" name='sectionname' /></td>
        </tr>
        <tr>
            <td>Audio Transcript</td>
            <td><textarea  id="editor1" name='audiotranscript' ></textarea></td>
        </tr>
        <tr>
            <td>Html Content</td>
            <td><textarea  id="editor2" name='htmlcontent' ></textarea></td>
        </tr>
        <tr>
            <td>Information Text
            </td>
            <td><textarea  id="editor3" name='information' ></textarea></td>
        </tr>
       
    </table>
    <input type="submit" value="Save"/>
</form>    
</div>
<div class="col s12 m4 l4">
    <form name="audio_form" id="audio_form" action="mp3-upload.php" method="post" enctype="multipart/form-data">
<div class="col s12 m12 l12">
    <label>Audio File:</label>
<div class="col s12 m12 l12">
        <input name="audio_file"  id="audio_file" type="file"/>
    </div>
<div class="col s12 m12 l12">
<input type="submit" name="Submit" id="Submit" value="Submit"/>
    </div>
</div>

</form>  
</div>
</div>
<?php else:?>
<div class="row">
    <div class="col s12 m8 l8">
    <h3>Update the existing user :</h3>
    <form method="POST" action="process.php?update">
        <table>
            <tr>

                <td><input type='hidden' name='id' value='<?php echo $frame->attributes()->id;?>'/></td>
            </tr>
            <tr>
               <td>Frame Name</td>
                <td><input type="text" name='framename' value="<?php echo $frame->framename;?>" /></td>
            </tr>
            <tr>
                  <td>Section Name</td>
                <td><input type="text" name='sectionname' value="<?php echo $frame->sectionname;?>" /></td>
            </tr>
            <tr>
                <td>Audio Transcript</td>
                <td><textarea  id="editor1" name='audiotranscript' ><?php echo $frame->audiotranscript;?></textarea></td>
            </tr>
            <tr>
                <td>Html Content</td>
                <td><textarea  id="editor2" name='htmlcontent' ><?php echo $frame->htmlcontent;?></textarea></td>
            </tr>
            <tr>
                <td>Information Text
            </td>
                <td><textarea  id="editor3" name='information' ><?php echo $frame->information; ?></textarea></td>
            </tr>
          
        </table>
        <input type="submit" value="Save"/>
    </form>
    </div>
    <div class="col s12 m4 l4">
 <a href="multifile-upload/mp3upload.php">Upload all audio</a>
<div class="col s12 m12 l12">
      <audio controls preload="auto">
    <source src='audios/<?php echo "f".$frame->attributes()->id.".mp3";?>' type="audio/mpeg">
    </audio>  
</div>
</div>
</div>
<?php endif;?>
<script>
	initSample();
</script>