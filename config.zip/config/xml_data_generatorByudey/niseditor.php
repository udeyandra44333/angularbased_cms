<?php
include("editor/index.php");
?>