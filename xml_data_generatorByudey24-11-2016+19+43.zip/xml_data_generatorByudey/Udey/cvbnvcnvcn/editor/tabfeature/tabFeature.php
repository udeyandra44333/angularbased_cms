<?php
if(isset($_POST['createtabs']))
{
    $pageid = $_POST['pageid'];
$tab1 = $_POST['tab1'];
$tab2 = $_POST['tab2'];
$tab3 = $_POST['tab3'];
$tab4 = $_POST['tab4'];
$tabtext1 = $_POST['tab_one_content'];
$tabtext2 = $_POST['tab_two_content'];
$tabtext3 = $_POST['tab_three_content'];
$tabtext4 = $_POST['tab_four_content'];
   
$tabfeaturescript = '$(document).ready(function(){
    $("ul.tabs").tabs();
  });';
  $tabfeature ='<!DOCTYPE html><html><head><title>Tab Feature</title></head><body><div class="row">
    <div class="col s12">
      <ul class="tabs tabs-fixed-width">
        <li class="tab col s3"><a href="#test1">'.$tab1.'</a></li>
        <li class="tab col s3"><a class="active" href="#test2">'.$tab2.'</a></li>
        <li class="tab col s3"><a href="#test3">'.$tab3.'</a></li>
        <li class="tab col s3"><a href="#test4">'.$tab4.'</a></li>
      </ul>
    </div>
    <div id="test1" class="col s12">'.$tabtext1.'</div>
    <div id="test2" class="col s12">'.$tabtext2.'</div>
    <div id="test3" class="col s12">'.$tabtext3.'</div>
    <div id="test4" class="col s12">'.$tabtext4.'</div>
  </div><script>'.$tabfeaturescript.'</script></body></html>'; 
$tabPageCreate = fopen('../../project/page'.$pageid.'.html', "w") or die("Unable to open file!");
fwrite($tabPageCreate, $tabfeature);
fclose($tabPageCreate);
echo "Succesfully created";
}
 
?>