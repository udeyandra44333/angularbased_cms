<?php
include_once 'dbconfig.php';
if(isset($_POST['btn-upload']))
{    
     
	$file = rand(1000,100000)."-".$_FILES['blogimage']['name'];
    $file_loc = $_FILES['blogimage']['tmp_name'];
    $imagetitle = $_POST['imagetitle'];
    $blogdate = $_POST['date_data'];
    $blogdescription = $_POST['blogdescription'];
	$file_size = $_FILES['blogimage']['size'];
	$file_type = $_FILES['blogimage']['type'];
	$folder="uploads/";
	
	// new file size in KB
	$new_size = $file_size/1024;  
	// new file size in KB
	
	// make file name in lower case
	$new_file_name = strtolower($file);
	// make file name in lower case
	
	$final_file=str_replace(' ','-',$new_file_name);
	
	if(move_uploaded_file($file_loc,$folder.$final_file))
	{
		$sql="INSERT INTO blogdata(blogimage,imagetitle,date_data,blogdesciption,type,size) VALUES('$final_file','$imagetitle','$blogdate','".mysql_real_escape_string($blogdescription)."','$file_type','$new_size')";
		mysql_query($sql);
		?>
		<script>
		alert('successfully uploaded');
        window.location.href='index.php?success';
        </script>
		<?php
	}
	else
	{
		?>
		<script>
		alert('error while uploading file');
        window.location.href='index.php?fail';
        </script>
		<?php
	}
}
?>