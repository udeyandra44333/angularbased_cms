<?php
error_reporting(0);

class Process
{
    protected $_xml;
    protected $path;

    public function __construct()
    {
        $this->_xml = simplexml_load_file("../project/transcript/data.xml");
    }

    public function getXml()
    {
        return $this->_xml;
    }

    /**
     * @param mixed $path
     */
    public function setPath($path)
    {
        $this->path = $path;
    }

    /**
     * @return mixed
     */
    public function getPath()
    {
        return $this->path;
    }

    public function userlist()
    {

        echo "<div id='table-wrapper'>
        <h5>Story Board</h5>
  <div id='table-scroll'>
        <table border='1' class='highlight toggletable' id='table-demo' width='900'>
            <thead>
                <tr>
                    <td>Page ID</td>
                    <td>Framename</td>
                    <td>Sectioname</td>
                    <td>Audiotranscript</td>
                    
                    <td>Html Content</td>
                    <td>Information</td>
                    <td>Action</td>
                    <td>Pages</td> 
                    <td>Commit Pages</td> 
                </tr>
            </thead>
        ";

        foreach ($this->_xml as $frame) {
            echo "
            <tr id='page{$frame->attributes()->id}'>
                    <td>{$frame->attributes()->id}
                    </td>
                    <td>{$frame->framename}
                    </td>
                    <td>{$frame->sectionname}
                    </td>
                    <td>{$frame->audiotranscript}
                    </td>
                    <td>{$frame->htmlcontent}
                    
                    </td>
                    <td>{$frame->information}
                    </td>
                    <td>
                     <a href='process.php?edit=" . $frame->attributes()->id . "' class='onlybt nobg margin-top-10 tooltipped' data-position='left' data-delay='50' data-tooltip='Edit'><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a>
                     <a href='process.php?delete=" . $frame->attributes()->id . "' class='nobg margin-top-10 onlybt tooltipped' data-position='left' data-delay='50' data-tooltip='Delete'><i class='fa fa-trash-o' aria-hidden='true'></i></a>
                    </td>
                   
                    <td>
                    page {$frame->attributes()->id}.html
        
         </td>
          <td>
                    <form action='createfiles.php' method='post' enctype='multipart/form-data'>
                     <textarea class='hidden' name='pageid'>{$frame->attributes()->id}</textarea>
                     <textarea class='hidden' name='framecontent'>{$frame->htmlcontent}</textarea>
                     <div id='audio-page'>Audio Page</div>
                     <button type='submit' name='btn-upload' class='nobg onlybt tooltipped' data-position='left' data-delay='50' data-tooltip='Audio Page'><i class='fa fa-volume-up' aria-hidden='true'></i></button>
                     </form>
                     <form action='createfiles.php' method='post' enctype='multipart/form-data'>
                     <textarea class='hidden' name='no_audio_pageid'>{$frame->attributes()->id}</textarea>
                     <textarea class='hidden' name='no_audio_framecontent'>{$frame->htmlcontent}</textarea>
                     <button type='submit' name='non-audio' class='margin-top-10 nobg onlybt tooltipped' data-position='left' data-delay='50' data-tooltip='Normal Page'><i class='fa fa-html5' aria-hidden='true'></i></button>
                     </form>
                    </td>
            </tr>
            
            </div></div>";
        }
       
    }

    public function filterList($post)
    {
        $xml = $this->_xml->xpath('frame[audiotranscript="' . strtolower($post) . '"]');

        echo "
        <table border='1' class='highlight'>
            <thead>
                <tr>
                      <td>Page ID</td>
                    <td>Framename</td>
                    <td>Sectioname</td>
                    <td>Audiotranscript</td>
                    <td>Html Content</td>
                    <td>Information</td>
                    <td>Action</td>
                </tr>
            </thead>
        ";

        foreach ($xml as $frame) {

            echo "
            <tr>
                    <td>{$frame->attributes()->id}
                    </td>
                    <td>{$frame->framename}
                    </td>
                    <td>{$frame->sectionname}
                    </td>
                    <td>{$frame->audiotranscript}
                    </td>
                    <td>{$frame->htmlcontent}
                    </td>
                    <td>{$frame->information}
                    
                    </td>
            </tr>
            ";
        }
        echo "</table>";
    }

    public function adduser($post)
    {
        if ($post["framename"] != "" &&
            $post["id"] != "" &&
            $post["sectionname"] != "" &&
            $post["audiotranscript"] != "" &&
            $post["htmlcontent"] != "" &&
            $post["information"] != ""
            //$post["user_notes"] != ""
        ) {

            $xml = $this->_xml;
            $frame = $xml->addChild('frame');
            $framename = $frame->addChild("framename", $post["framename"]);
            $sectionname = $frame->addChild("sectionname", $post["sectionname"]);
            $pers = $frame->addChild("audiotranscript", $post["audiotranscript"]);
            $htmlcontent = $frame->addChild("htmlcontent", $post["htmlcontent"]);
            $information = $frame->addChild("information", $post["information"]);
            //$user_notes = $frame->addChild("user_notes", $post["user_notes"]);
            $frame->addAttribute("id", $post["id"]);
            $xml->asXML($this->path);
            echo "<div class='addedMessage animated fadeInDown block' id='addPage'><div class='closeit'></div><p>added successfully</p></div>";
          
        }
           
    }

    public function getUserById($id)
    {
        $frame = $this->_xml->xpath('//frame[@id="' . $id . '"]');
        return $frame[0];
    }

    public function updateUser($post)
    {
        $frame = $this->_xml->xpath('//frame[@id="' . $post['id'] . '"]');

//        $user[0]['id'] = (int) $post["id"];
        $frame[0]->framename = $post["framename"];
        $frame[0]->sectionname = $post["sectionname"];
        $frame[0]->audiotranscript = $post["audiotranscript"];
        $frame[0]->htmlcontent = $post["htmlcontent"];
        $frame[0]->information = $post["information"];
        $this->_xml->asXML($this->path);
    }
 
}

//Include template
// Optionally Disable browser caching on "Back"
header( 'Cache-Control: no-store, no-cache, must-revalidate' );
header( 'Expires: Sun, 1 Jan 2000 12:00:00 GMT' );
header( 'Last-Modified: ' . gmdate('D, d M Y H:i:s') . 'GMT' );

$post_hash = md5( json_encode( $_POST ) );

if( session_start() )
{
    $post_resubmitted = isset( $_SESSION[ 'post_hash' ] ) && $_SESSION[ 'post_hash' ] == $post_hash;
    $_SESSION[ 'post_hash' ] = $post_hash;
    session_write_close();
}
else
{
    $post_resubmitted = false;
}

if ( $post_resubmitted ) {
  //include 'index.php';
  unset($_POST);
    include 'index.php';
}
else
{
    include 'index.php';
  // POST was submitted normally
}



//$xml->user[0]->name = "Gayan, Hewa";
//$xml->asXML($completeurl);


//Controller
$param = $_SERVER['QUERY_STRING'];
$arr = explode("=", $param);
if (count($arr) > 1) {
    $param = $arr[0];
}
//$path = getcwd()."/project/transcript/data.xml";
$path = "../project/transcript/data.xml";
$process = new Process();
$process->setPath($path);
if ($param == "list") {
    $process->userlist();
}
if ($param == "add") {
    $post = $_POST;
    $process->adduser($post);
    include 'user.php';
     
}
if ($param == "filter") {
    $post = $_POST["pers"];
    $process->filterList($post);
}

if ($param == "delete") {
    $id = $arr[1];
    $i = 0;
    foreach ($process->getXml() as $frame){
        if ($frame->attributes()->id == $id){
            unset($process->getXml()->frame[$i]);
            $process->getXml()->asXML($path);
            break;
        }
        $i++;
    }
}

if ($param == "edit") {
    $id = $arr[1];
    $frame = $process->getUserById($id);
    include 'user.php';
    
}

if ($param == "update") {
    $post = $_POST;
    $process->updateUser($post);
    echo "Updated successfully";
}

?>
