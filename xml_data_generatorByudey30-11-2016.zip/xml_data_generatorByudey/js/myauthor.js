var projectname;
function validateCreateproject()
{
      var x = document.forms["createProject"]["project"].value;
    if (x == null || x == "") {
        $("#hint").removeClass("active");
        $("#hint").show().text("Please add your project name")
        return false;
    }
    else{
       setTimeout(function(){
           $(".go_to_next").hide();
           $(".template-box").show();
           $(".successMessage").show();
            $(".text-box").hide();
        $(".step1").hide();
       },100);  
    }
}

var windowHeight = $(window).height();
$(document).ready(function(){
/*$('tr', 'table').each(function(i) {
    $(this).attr("id","page"+i+1);
});*/
    $(".singlechoicequiz").show(function(){
        $(this).addClass("tog");
    });
    $(".singlechoiceshow").addClass("boffin-border");
setTimeout(function(){
    $('#preloader').hide();
},300);

/*Scale a table*/
var HeightDiv = $("#table-scroll").height();
    var HeightTable = $("table").height();
    if (HeightTable > HeightDiv) {
        var FontSizeTable = parseInt($("table").css("font-size"), 12);
        while (HeightTable > HeightDiv && FontSizeTable > 12) {
            FontSizeTable--;
            $("table").css("font-size", FontSizeTable);
            HeightTable = $("table").height();
        }
    }    
/*End of scaling*/
   $('.tooltipped').tooltip({delay: 50});
$("aside").css({"height":+windowHeight});
$( ".gettext" ).focus(function() {
  $("#hint").hide();
});$( ".with-gap" ).focus(function() {
  $(".errormsg").hide();
});
$("#imageUpload").submit(function(event){
   $(".validationMessage").show(); 
   $(".logoUpload").show(); 
    $(".homescreenUpload").hide();
});
$("#launchscreenform").submit(function(event){
   $(".validationMessage").show(); 
   $(".homescreenUpload").show(); 
    $(".logoUpload").hide(); 
});


    $('.go_to_next').submit(function (event) {
        validateCreateproject();
        projectname =  $(".gettext").val();
        $(".texttoextrct").val(projectname);
        $(".foldername_p").val(projectname);
     
        event.preventDefault();
 return false;
});
  $(".choose_template").submit(function(event){
      setTimeout(function(){
         location.reload();
      },2000);
    
  });  

    $("#customui").on("click",function(){
        $(".uicustom").toggle();
        $(".overlay").toggle();
    });
$(".close-icon").on("click",function(){
        $(".uicustom").toggle();
        $(".overlay").toggle();
    });
$(".listofimages").on("click",function(){
        $(".dialogbox").toggle();
        $(".overlay_bx").toggle();
    });$(".close-iconx").on("click",function(){
        $(".dialogbox").toggle();
        $(".overlay_bx").toggle();
    });
   /* $(".show-projectlinkview").on("click",function(){
        
       
        $(this).next().slideToggle();
        $(this).parent().addClass("active");
        
    });*/
$(".dropdown1").on("click",function(){
   $(this).next().slideToggle(); 
$(".dropdown2").next().hide();
$(".dropdown3").next().hide();
   
});$(".dropdown2").on("click",function(){
   $(this).next().slideToggle(); 
    $(".dropdown1").next().hide();
$(".dropdown3").next().hide();
   
});$(".dropdown3").on("click",function(){
   $(this).next().slideToggle(); 
    $(".dropdown1").next().hide();
$(".dropdown2").next().hide();
   
});
$(".showsignout").on("click",function(){
    $(this).children().next().toggle();
});
    $("#animationlist").on("click",function(){
        
        $(".slidemenu").toggle("slide");
    });
    $(".closemenu").on("click",function(){
        
        $(".slidemenu").toggle("slide");
    });
    $(".preview_animation").on("click",function(){
        
        $(".effect").toggleClass("animated");
      
   
    });
    $(document).on("click",".getUrl",function(){
        $(this).prop("contentEditable","true");
    });
  
 $(".contentVideo").on("click",function(){
    $(".content-video").show();
    $(".content-video-overlay").show();
}); $(".frameVideo").on("click",function(){
    $(".frame-video").show();
    $(".frame-video-overlay").show();
});
$(".singlechoice").on("click",function(){
    $(".quiz-integrate").show();
    $(".quiz-integrate-overlay").show();
});
$(".assesment").on("click",function(){
    $(".assesmentCreator").show();
    $(".assesmentCreatorOverlay").show();
});
$(".tabfeature").on("click",function(){
    $(".integrate-tabfeature").show();
    $(".tabfeature-overlay").show();
});
$(".coursenmoduleTitle").on("click",function(){
    $(".coursenmodule").show();
    $(".coursenmoduleOverlay").show();
});
    /*On change show editor*/
    $("select").change(function(){
        $(this).find("option:selected").each(function(){
            if($(this).attr("value")=="quiz"){
                $(".hideeditor").show(function(){
                  $("table tr.audiotranscript").hide();
                  $("table tr.htmlcontent").hide();
                    $(".framename").prop("readonly","true");
                    $(".sectionname").prop("readonly","true");
                  $(".framename").val("Quiz");
                  $(".sectionname").val("Learning Activity");
                });
               
            }
            else if($(this).attr("value")=="page"){
                $(".hideeditor").show(function(){
                  $("table tr.audiotranscript").show();
                  $("table tr.htmlcontent").show();
                    $(".framename").removeAttr("disabled","false");
                    $(".sectionname").removeAttr("disabled","false");
                    $(".framename").val("");
                  $(".sectionname").val("");
                });
            }
            else if($(this).attr("value")=="blue"){
                $(".box").not(".blue").hide();
                $(".blue").show();
            }
            else{
                $(".box").hide();
            }
        });
    }).change();
$(".closeit").on("click",function(){
    $(".integrate-tabfeature").hide();
    $(".coursenmodule").hide();
    $(".quiz-integrate").hide();
    $(".assesmentCreator").hide();
    $(".coursenmoduleOverlay").hide();
    $(".tabfeature-overlay").hide();
    $(".quiz-integrate-overlay").hide();
    $(".assesmentCreatorOverlay").hide();
    $(".validationMessage").hide();
    $(".addedMessage").hide();
    $(".content-video").hide();
    $(".content-video-overlay").hide();
    $(".frame-video-overlay").hide();
    $(".frame-video").hide();
});
    $(".singlechoiceshow").on("click",function()
         {
        $(this).addClass("boffin-border");
        $(".dragndropshow").removeClass("boffin-border");
        $(".dragndropquiz").hide();
        $(".dragndropquiz").removeClass("tog");
      if($(".singlechoicequiz").find("tog")){
          $(".singlechoicequiz").show();
      }
    });
   $(".dragndropshow").on("click",function()
         {
       $(this).addClass("boffin-border");
        $(".singlechoiceshow").removeClass("boffin-border");
       $(".dragndropquiz").addClass("tog");
       $(".singlechoicequiz").removeClass("tog");
       $(".singlechoicequiz").hide();
      if($(".dragndropquiz").find("tog")){
          $(".dragndropquiz").show();
      }
    });

    /*End of editor*/
$('.collapsible').collapsible();
$('#table-demo').DataTable();
    /*   $('#table-demo').paging({

limit: 5,
rowDisplayStyle: 'block',
activePage: 0,
rows: []

});*/
});
