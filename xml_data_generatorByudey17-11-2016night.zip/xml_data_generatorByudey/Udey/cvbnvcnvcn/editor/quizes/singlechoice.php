<form method="post" enctype="multipart/form-data">
<label>
Page ID
<input type="text" name="pageid" placeholder="Enter page id" />
</label>
<label>
Question
<input type="text" name="question" placeholder="Enter Question" />
</label>
<label>
Options
<input type="text" name="option1" placeholder="Enter Option1" />
<input type="text" name="option2" placeholder="Enter Option2" />
<input type="text" name="option3" placeholder="Enter Option3" />
<input type="text" name="option4" placeholder="Enter Option4" />
<input type="text" name="option5" placeholder="Enter Option5" />
</label>
</form>
<?php
echo "Single Choice";
$srcfile='page'.$pageid.'.html';
//$dstfile='G:\Shared\Reports\Joe.txt';
mkdir(dirname($dstfile), 0777, true);
copy($srcfile, $dstfile);
?>