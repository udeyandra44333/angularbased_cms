-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2016 at 07:59 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myauthor`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `publicationDate` date NOT NULL,
  `title` varchar(255) NOT NULL,
  `summary` text NOT NULL,
  `content` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `publicationDate`, `title`, `summary`, `content`) VALUES
(1, '2016-10-14', 'asas', 'ppasdasdasdasdpp', 'sadasdasd');

-- --------------------------------------------------------

--
-- Table structure for table `directories`
--

CREATE TABLE `directories` (
  `id` int(11) NOT NULL,
  `userdirectory` varchar(200) NOT NULL,
  `userchilddirectory` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `directories`
--

INSERT INTO `directories` (`id`, `userdirectory`, `userchilddirectory`) VALUES
(1, 'astra', 'Blueish'),
(2, 'Ipsen', 'Blueish'),
(3, 'hghjjhbjkjhjkhjkjk', 'Blueish'),
(4, 'uop', 'project'),
(5, 'kol', 'project'),
(6, 'fsdf', 'project'),
(7, 'dfdsf', 'project'),
(8, 'jkkk', 'project'),
(9, 'zxzx', 'project'),
(10, 'dfdf', 'project'),
(11, 'jhj', 'project'),
(12, 'xfgdggg', 'project'),
(13, 'xfgdggg', 'project'),
(14, 'sdf', 'project'),
(15, 'dfdsfepe', 'project'),
(16, 'zvxcvxcv', 'project'),
(17, 'zvxcvxcv', 'project'),
(18, 'zvxcvxcv', 'project'),
(19, 'dsdsdlsls', 'project'),
(20, 'wewepep', 'project'),
(21, 'kjljjkjkj', 'project'),
(22, 'kjljjkjkj', 'project'),
(23, 'dfdfdf', 'project'),
(24, 'sdfjksdfjksdf', 'project'),
(25, 'aasqsqs', 'project'),
(26, 'wewewe', 'project'),
(27, 'vhjjhjh', 'project'),
(28, 'vhjjhjh', 'project'),
(29, 'jgghgh', 'project'),
(30, 'vhjjhjh', 'project'),
(31, 'dfdf', 'project'),
(32, 'hghgh', 'project'),
(33, 'hghgh', 'project'),
(34, 'dfgdfg', 'project'),
(35, 'dfgdfg', 'project'),
(36, 'jjj', 'project'),
(37, 'jjj', 'project'),
(38, 'ddfrgrgtgf', 'project'),
(39, 'ddfrgrgtgf', 'project'),
(40, 'dfhfgfghfhsghsgh', 'project');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(5) NOT NULL,
  `user_name` varchar(25) NOT NULL,
  `user_email` varchar(35) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_email`, `user_pass`, `country`, `mobile`) VALUES
(1, 'Udey', 'udeya.88@gmail.com', '7f84d23622b5f12d35ba98ea9ba930d1', 'd41d8cd98f00b204e9800998ecf8427e', ''),
(2, 'Udey', 'udeya.90@gmail.com', 'b5bcb36f6e7f45739ecf75acec6fc22b', '7d31e0da1ab99fe8b08a22118e2f402b', ''),
(3, 'Udey', 'alessiaanika62@gmail.com', 'b5bcb36f6e7f45739ecf75acec6fc22b', '7d31e0da1ab99fe8b08a22118e2f402b', ''),
(4, 'Udey', 'udeyandra.kumar@indegene.com', 'b5bcb36f6e7f45739ecf75acec6fc22b', '7d31e0da1ab99fe8b08a22118e2f402b', ''),
(5, 'udeyandra', 'udeya.98@gmail.com', 'b5bcb36f6e7f45739ecf75acec6fc22b', '11a98374ebec8e0c7a54751d2161804d', ''),
(6, 'udeyandra', 'udeya.78@gmail.com', 'b5bcb36f6e7f45739ecf75acec6fc22b', '11a98374ebec8e0c7a54751d2161804d', ''),
(7, 'udeyandra21', 'udeya.989@gmail.com', 'b5bcb36f6e7f45739ecf75acec6fc22b', '11a98374ebec8e0c7a54751d2161804d', ''),
(8, 'better', 'udeya.56@gmail.com', '7f84d23622b5f12d35ba98ea9ba930d1', '11a98374ebec8e0c7a54751d2161804d', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `directories`
--
ALTER TABLE `directories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `directories`
--
ALTER TABLE `directories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
