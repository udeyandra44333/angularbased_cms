<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>XML CRUD APP</title>
      <meta charset="utf-8">
    <title>XML CRUD APP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <script src="../js/jquery-3.1.1.js"></script>
    <script src="../ckeditor.js"></script>
	<script src="../js/editorsnis.js"></script>
<link rel="stylesheet" href="css/ckeditor.css" />
<link rel="stylesheet" href="../css/myauthor.css" />
<link rel="stylesheet" href="../css/animate.css" />
<link rel="stylesheet" type="text/css" href="../css/editor.css" />
<link rel="stylesheet" type="text/css" href="../css/materialize.css" />
</head>
<body>
    <ul>
        <li><a href="process.php?list">List All Users</a></li>
        <li><a href="process.php?add">Add User</a></li>
    </ul>
  
</body>
 

</html>