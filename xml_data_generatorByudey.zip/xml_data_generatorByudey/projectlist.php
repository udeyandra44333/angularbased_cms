<ul class="collapsible" data-collapsible="accordion">
<?php
include ("dbconnect.php");
 $select=mysql_query("SELECT * FROM directories");
$userfoldername = $userRow['user_name'];

/* Change this configuration in live domain*/
$domain = $_SERVER['SERVER_NAME']."/config/config/xml_data_generatorByudey";
$openText = "open";
  while($userrow=mysql_fetch_array($select))
  
  {
  $projectname=$userrow['userdirectory'];
  echo "<li><div class='col s12 m12 l12 collapsible-header'>".$projectname."</div><div class='col s12 m12 l12 collapsible-body'><a href='http://$domain/$userfoldername/$projectname/editor/process.php?list' class='margin-right-10 projectlink-preview'>".$openText."</a><a href='http://$domain/$userfoldername/$projectname/project/' class='margin-right-10 projectlink-preview' target='_blank'>Preview</a></div></li>";
  }
?>
</ul>