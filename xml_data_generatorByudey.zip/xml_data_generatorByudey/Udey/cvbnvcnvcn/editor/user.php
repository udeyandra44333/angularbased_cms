
<?php if (!isset($id) || $id == "") :?>

<div class="row">

<div class="col s12 m12 l12 toggletable">
 <h3>Add New Record</h3>
       <div class="col s12 m12 l12">
    <div class="col s12 m6 l6">
 <?php include("mp3-upload.php"); ?>  
    </div>
    <div class="col s12 m6 l6">
    <?php include("multi-image.php"); ?>
    </div>



</div>
<form method="POST" action="process.php?add">
    <table>
        <tr>
            <td>Page ID</td>
            <td><input type='text' name='id'/></td>
        </tr>
        <tr>
            <td>Frame Name</td>
            <td><input type="text"  name='framename' /></td>
        </tr>
        <tr>
            <td>Section Name</td>
            <td><input type="text" name='sectionname' /></td>
        </tr>
        <tr>
            <td>Audio Transcript</td>
            <td><textarea  id="editor1" name='audiotranscript' ></textarea></td>
        </tr>
        <tr>
            <td>Html Content</td>
            <td><textarea  id="editor2" name='htmlcontent' ></textarea></td>
        </tr>
        <tr>
            <td>Information Text
            </td>
            <td><textarea  id="editor3" name='information' ></textarea></td>
        </tr>
       
    </table>
    <input type="submit" value="Save"/>
</form>    
</div>

</div>
<?php else:?>
<div class="row">
    <div class="col s12 m12 l12 toggletable">
    <h3>Update the existing user :</h3>
        <div class="col s12 m12 l12">
    <div class="col s12 m6 l6">
    <div class="wrap">
          <form name="audio_form" id="audio_form" action="mp3-upload.php" method="post" enctype="multipart/form-data">
<fieldset class="fieldset">
<legend>Audio File:</legend>
<input name="audio_file" id="audio_file" type="file"/>
<input type="submit" name="Submit" id="Submit" value="Submit"/>
          <!-- <div class="col s12 m12 l12">
      <audio controls preload="auto">
    <source src='audios/<?php echo "f".$frame->attributes()->id.".mp3";?>' type="audio/mpeg">
    </audio>  
</div>-->
</fieldset>
</form>  
    </div>
    </div>
    <div class="col s12 m6 l6">
    <?php include("multi-image.php"); ?>
    </div>



</div>
<form method="POST" action="process.php?update">
        <table>
            <tr>

                <td><input type='hidden' name='id' value='<?php echo $frame->attributes()->id;?>'/></td>
            </tr>
            <tr>
               <td>Frame Name</td>
                <td><input type="text" name='framename' value="<?php echo $frame->framename;?>" /></td>
            </tr>
            <tr>
                  <td>Section Name</td>
                <td><input type="text" name='sectionname' value="<?php echo $frame->sectionname;?>" /></td>
            </tr>
            <tr>
                <td>Audio Transcript</td>
                <td><textarea  id="editor1" name='audiotranscript' ><?php echo $frame->audiotranscript;?></textarea></td>
            </tr>
            <tr>
                <td>Html Content</td>
                <td><textarea  id="editor2" name='htmlcontent' ><?php echo $frame->htmlcontent;?></textarea></td>
            </tr>
            <tr>
                <td>Information Text
            </td>
                <td><textarea  id="editor3" name='information' ><?php echo $frame->information; ?></textarea></td>
            </tr>
          
        </table>
        <input type="submit" value="Save"/>
    </form>
    </div>

</div>

<?php endif;?>
<script>
	initSample();
</script>