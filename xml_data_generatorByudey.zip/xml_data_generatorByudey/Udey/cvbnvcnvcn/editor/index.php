<?php
session_start();
include_once '../../../dbconnect.php';

if(!isset($_SESSION['user']))
{
	header("Location: ../../../index.php");
}
$res=mysql_query("SELECT * FROM users WHERE user_id=".$_SESSION['user']);
$userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>XML CRUD APP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <script src="js/jquery-3.1.1.js"></script>
    <script src="ckeditor.js"></script>
	<script src="js/editorsnis.js"></script>
      <!--Let browser know website is optimized for mobile-->
    <script src="../../../js/myauthor.js"></script>
    <script src="js/jscolor.js"></script>
<link rel="stylesheet" href="css/ckeditor.css" />
<link rel="stylesheet" href="../../../css/myauthor.css" />
<link rel="stylesheet" href="../../../css/animate.css" />
<link rel="stylesheet" type="text/css" href="css/editor.css" />
<link rel="stylesheet" type="text/css" href="css/materialize.css" />
<style>
.margin-top-60 {
    margin-top: -126px;
}    
</style>
</head>
<body>
    <div class="overlay">
    
</div> 
<div class="overlay_bx">
    
</div>
<div class="dialogbox">
    <div class="close-iconx btn">Close</div>
<div class="imaging">
   <?php include("list_of_images.php");
    ?> 
</div>
</div>
<?php
     include_once '../../../animationlist.php';
    ?>
    <?php
    include_once '../../../subheader.php';
    /*Need to change during live*/
    $url = $_SERVER['REQUEST_URI'];
$tokens = explode('/', $url);
$previewspec = $tokens[sizeof($tokens)-3];
    ?>
    <div class="col s12 m12 l12 padding-0 margin-top-60">
    <div class="col s12 m12 l12 padding-0">
<div class="col s12 m2 l2 padding-0">
 <aside class="col s12 m12 l12 padding-0">
<h6 align="center">List of projects</h6>		
<?php
include("../../../projectlist.php");
?>

		
	</aside>   
</div>
<div class="col s12 m10 l10 loadeditor padding-0">

    <!--<ul>
        <li><a href="process.php?list">List Pages</a></li>
        <li><a href="process.php?add">Add Pages</a></li>
    </ul>  -->
     <nav>
    <div class="nav-wrapper margin-top-4">
      <ul id="nav-mobile" class="left hide-on-med-and-down">
           <?php
   echo "<li><a href='http://$domain' >Go Back</a></li>";
       ?>
        <li><a href="process.php?list">Page List</a></li>
        <li><a href="process.php?add">Add Page</a></li>
        <li><a href="#" id="customui">Customize UI</a></li>
        <li class="glsry"><a href="#">Create Glossary</a>
          <ul>
            <li><a href="#" class="glossarylist">Show glossary</a></li>
              <li><a href="#" class="addglossary">Create glossary</a></li>
            </ul>
          </li>
        <li><a href="#" class="listofimages">Show Images</a></li>
        <li><a href="#" id="animationlist">Animation list</a></li>
        <li class="glsry"><a href="#" id="quizes" >Features</a>
          <ul>
              <li><a href="#">Tab Feature</a></li>
            <li><a href="#" class="singlechoice">Quiz</a></li>
              <li><a href="#" class="assesment">Assesment</a></li>
            </ul>
          </li>
        <li class="glsry"><a href="#" >Video</a>
          <ul>
            <li><a href="#" class="contentVideo">Content Video</a></li>
            <li><a href="#" class="frameVideo">Frame Video</a></li>
            </ul>
          </li>
        <li><?php echo "<a href='http://$domain/$userfoldername/$previewspec/project' target='_blank'>Preview</a>" ?></li>
      </ul>
    </div>
  </nav>

     <div class="uicustom">
    <div class="headersection">
         <h5 class="modalheader">Header</h5>
        <div class="close-icon btn">Close</div>
         </div>
    <div class="uicust-body">
<div class="col s12 m12 l12">
     <div class="col s12 m6 l6">
         <div class="col s12 m12 l12">
        <form action="uploadlogo.php" method="POST" enctype="multipart/form-data">
        <fieldset>
<legend>Logo File:</legend>
         <input type="file" name="image" />
         <input type="submit"/>
        </fieldset>
      </form>
    </div>
    </div>  
    <div class="col s12 m6 l6">
    <div class="col s12 m12 l12">
        <form action="homescreen.php" method="POST" enctype="multipart/form-data">
        <fieldset>
<legend>Homescreen File:</legend>
         <input type="file" name="image" />
         <input type="submit"/>
        </fieldset>
      </form>
    </div>   
    </div>
</div>
<form action="header-footercss.php" method="post" enctype="multipart/form-data">
        <div class="col s12 m6 l6">
           <div class="col s12 m12 l12">
        <fieldset>
        <legend>Player Header/Footer</legend>
           <label>Header/Footer Bg
         <input class="jscolor" name="bgcolor1" value="transparent">
            </label> 
        <label>Header/Footer Text Color
         <input class="jscolor" name="headertextcolor" value="transparent">
            </label>
        <label>Frame/Section name color
         <input class="jscolor" name="framesectioncolor" value="transparent">
            </label>
            </fieldset>
        </div>
        <div class="col s12 m12 l12">
        <fieldset>
         <legend>Timeline</legend>
              <label>Timeline color
         <input class="jscolor" name="timeline" value="transparent">
            </label>
        <label>Progressbar color
         <input class="jscolor" name="timelinecolor" value="transparent">
            </label>
            </fieldset>
        </div>   
        <div class="col s12 m12 l12">
        <fieldset>
         <legend>Frame Container</legend>
              <label>Add Background
         <input class="jscolor" name="framebg" value="transparent">
            </label>  
        <label>Add frame text color
         <input class="jscolor" name="frametext" value="transparent">
            </label>
            </fieldset>
        </div>  
        <div class="col s12 m12 l12">
        <fieldset>
         <legend>Glossary</legend>
              <label>Add Background
         <input class="jscolor" name="glossarybg" value="transparent">
            </label>  
        <label>Add text color
         <input class="jscolor" name="glossarytext" value="transparent">
            </label>
            </fieldset>
        </div>
        </div>
        <div class="col s12 m6 l6">
              <div class="col s12 m12 l12">
        <fieldset>
        <legend>Menu Background</legend>
            <label>
            Menu Bg
            <input class="jscolor" name="menuboxbg" value="transparent" />
            </label> 
            <label>
            Menu icons color
            <input class="jscolor" name="iconcolor" value="transparent" />
            </label> 
            <label>
            Dropdown Menu Item Text color
            <input class="jscolor" name="menuitemtext" value="transparent" />
            </label>
            <label>
            Dropdown Menu Title text
            <input class="jscolor" name="title_menu_text" value="transparent" />
            </label>
            <label>
            Dropdown Menu Title BG
            <input class="jscolor" name="title_menu_bg" value="transparent" />
            </label>
            </fieldset>       
        </div>
        <div class="col s12 m12 l12">
        <fieldset>
            <legend>Transcript</legend>
            <label>Transcript Background
         <input class="jscolor" name="audiotranscriptbg" value="transparent">
            </label>
        <label>
            Transcript Title Text Color
            <input class="jscolor" name="transcript_title_color" value="transparent">
            </label>
        <label>
            Transcript Text
            <input class="jscolor" name="transcript_text" value="transparent">
            </label>
            </fieldset>
            </div>
        </div>
    <div class="col s12 m12 l12">
    <input type="submit" name="css-upload" />           
    </div>       
      </form>
         </div>
    </div>
<div class="glossarymodal">
<iframe src="glossary/process.php?add" width="100%" height="100%" class="iframesrc" frameborder="0" scrolling="no"></iframe>  
    
</div>
<div class="content-video white">
<h5>Content Videos</h5>
    <div class="row">
    <div class="col s12 m12 l12">
    <?php include("content-video.php"); ?>    
    </div>
    </div>
</div>
<div class="content-video-overlay"></div>
<div class="frame-video white">
<h5>frame Videos</h5>
    <div class="row">
    <div class="col s12 m12 l12">
    <?php include("frame-video.php"); ?>    
    </div>
    </div>
</div>

<div class="frame-video-overlay"></div>
<div class="quiz-integrate white">
<h5>Single choice Quiz</h5>
<div class="row">
<div class="col s12 m12 l12">
    <div class="col s12 m12 l12 singlechoice">
    <?php
    include("quizes/singleandmultiplechoice.php");
    ?>
    </div>
    <div class="col s12 m12 l12 dragndrop">
    <h6>Create drag and drop</h6>
    <div class="col s12 m12 l12">
        <form action="quizes/dragndrop.php" method="post" enctype="multipart/form-data">
        <input type="text" name="pageid" placeholder="Enter your PageID" />
        <input type="text" name="itemrange" placeholder="Define number of items" />
        <textarea name="draggableQuest">Question1,Question2 and so on</textarea>
        <textarea name="draggableData">Answer1,Answer2 and so on</textarea>
            <input type="submit" name="dragndrop" value="Create" class="btn large" />
        </form>
    </div>
    </div>
</div>    
</div>    
</div>
<div class="quiz-integrate-overlay">
    
</div>
     <script type="text/javascript" src="js/materialize.min.js"></script>
</body>
 

</html>







