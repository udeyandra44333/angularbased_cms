<div class="slidemenu">
    <div class="row">
    <div class="col s6 m6 l6">
    <h6>Effect List</h6>    
    </div>
    <div class="col s6 m6 l6">
        <a href="#" class="btn closemenu">Close</a>
    </div>
    </div>
     <ul class="collapsible box-shadow-0 effectlist" data-collapsible="accordion">
    <li>
      <div class="collapsible-header">Fade In</div>
      <div class="collapsible-body addheight-65">
          <div class="row">
              <div class="col s12 m12 l12 animated infinite fadeIn effect">fadeIn</div>
              <div class="col s12 m12 l12">Effect Name : fadeIn</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header">Fade In Down</div>
      <div class="collapsible-body addheight-65">
          <div class="row">
              <div class="col s12 m12 l12 animated infinite fadeInDown effect">fadeIn Down</div>
              <div class="col s12 m12 l12">Effect Name : fadeInDown</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header">FadeIn Left</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite fadeInLeft effect">fadeIn Left</div>
              <div class="col s12 m12 l12">Effect Name : fadeInLeft</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header">FadeIn Right</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite fadeInRight effect">fadeIn Right</div>
              <div class="col s12 m12 l12">Effect Name : fadeInRight</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header">FadeIn Up</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite fadeInUp effect">fadeIn Up</div>
              <div class="col s12 m12 l12">Effect Name : fadeInUp</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header">Flip In X</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite flipInX effect">Flip In X</div>
              <div class="col s12 m12 l12">Effect Name : flipInX</div>
          </div>
        </div>
    </li>    
    <li>
      <div class="collapsible-header">Flip In Y</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite flipInY effect">Flip In Y</div>
              <div class="col s12 m12 l12">Effect Name : flipInY</div>
          </div>
        </div>
    </li> 
    <li>
      <div class="collapsible-header">Light Speed In</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite lightSpeedIn effect">Light Speed In</div>
              <div class="col s12 m12 l12">Effect Name : lightSpeedIn</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header">Slide In Up</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite slideInUp effect">Slide In Up</div>
              <div class="col s12 m12 l12">Effect Name : slideInUp</div>
          </div>
        </div>
    </li> 
    <li>
      <div class="collapsible-header">Slide In Left</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite slideInLeft effect">Slide In Left</div>
              <div class="col s12 m12 l12">Effect Name : slideInLeft</div>
          </div>
        </div>
    </li>   
     <li>
      <div class="collapsible-header">Slide In Right</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite slideInRight effect">Slide In Right</div>
              <div class="col s12 m12 l12">Effect Name : slideInRight</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header">Slide In Down</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite slideInDown effect">Slide In Down</div>
              <div class="col s12 m12 l12">Effect Name : slideInDown</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header">Zoom In</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite zoomIn effect">Zoom In</div>
              <div class="col s12 m12 l12">Effect Name : zoomIn</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header">Zoom In Down</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite zoomInDown effect">Zoom In Down</div>
              <div class="col s12 m12 l12">Effect Name : zoomInDown</div>
          </div>
        </div>
    </li>
    <li>
      <div class="collapsible-header">Zoom In Up</div>
      <div class="collapsible-body addheight-65">
        <div class="row">
              <div class="col s12 m12 l12 animated infinite zoomInDown effect">Zoom In Up</div>
              <div class="col s12 m12 l12">Effect Name : zoomInDown</div>
          </div>
        </div>
    </li>
  </ul> 
</div>