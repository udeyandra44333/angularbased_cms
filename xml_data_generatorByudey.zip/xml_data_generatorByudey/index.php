<?php
session_start();
include_once 'dbconnect.php';

if(isset($_SESSION['user'])!="")
{
	header("Location: home.php");
}

if(isset($_POST['btn-login']))
{
	$email = mysql_real_escape_string($_POST['email']);
	$upass = mysql_real_escape_string($_POST['pass']);
	
	$email = trim($email);
	$upass = trim($upass);
	
	$res=mysql_query("SELECT user_id, user_name, user_pass FROM users WHERE user_email='$email'");
	$row=mysql_fetch_array($res);
	
	$count = mysql_num_rows($res); // if uname/pass correct it returns must be 1 row
	
	if($count == 1 && $row['user_pass']==md5($upass))
	{
		$_SESSION['user'] = $row['user_id'];
		header("Location: home.php");
	}
	else
	{
		?>
        <script>alert('Username / Password Seems Wrong !');</script>
        <?php
	}
	
}
?>

<?php 
  include("header.php");  
?>
        
<div class="row">
<div class="col s12 m12 l12">
<div class="col s12 m8 l8 bluebgmid sliderheight">

</div>
        <div class="col s12 m4 l4 white">
          <div class="card white box-shadow-0 darken-1 padding-0">
            <div class="card-content padding-0 grey-text">
              <span class="card-title">Login</span>
            <form method="post">
             <input type="text" name="email" placeholder="Your Email" required />
             <input type="password" name="pass" placeholder="Your Password" required /> 
            
            </div>
            <div class="card-action border-0 padding-0">
             
             <button  type="submit" class="col s12 m12 l12 btn right bluebg" name="btn-login">Sign In</button>
            <a class="col s12 m12 l12" href="register.php">Sign Up Here</a>
            </div>
                </form>
          </div>
        </div>    
</div>

</div>
            
</div>   
<div class="row">
<div class="col s12 m12 l12 margin-bottom-63">
     <div class="col s12 m4 l4 white padding-0">
        <video preload="auto" controls class="col s12 m12 l12 sliderheight">
            <source src="coropratevideo/1.mp4" type="video/mp4" />
        </video>
    </div>
    <div class="col s12 m8 l8 bluebgmid sliderheight padding-0">
        
    </div> 
    </div>
</div>
<?php include("footer.php") ?>

    <link rel="stylesheet" type="text/css"  href="css/index.css" />
<!--https://colorlib.com/wp/free-bootstrap-admin-dashboard-templates/-->