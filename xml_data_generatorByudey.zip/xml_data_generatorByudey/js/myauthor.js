var projectname;
function validateCreateproject()
{
      var x = document.forms["createProject"]["project"].value;
    if (x == null || x == "") {
        $("#hint").show().text("Please add your project name")
        return false;
    }
    else{
       setTimeout(function(){
           $(".go_to_next").hide();
           $(".template-box").show();
           $(".successMessage").show();
       },100);  
    }
}
var windowHeight = $(window).height();
$(document).ready(function(){
    $('.collapsible').collapsible();
     $(".dropdown-button").dropdown();
$("aside").css({"height":+windowHeight});
$( ".gettext" ).focus(function() {
  $("#hint").hide();
});$( ".with-gap" ).focus(function() {
  $(".errormsg").hide();
});
    $('.go_to_next').submit(function (event) {
        validateCreateproject();
        projectname =  $(".gettext").val();
        $(".texttoextrct").val(projectname);
        $(".foldername_p").val(projectname);
        event.preventDefault();
 return false;
});
  $(".choose_template").submit(function(event){
      setTimeout(function(){
         location.reload();
      },2000);
    
  });  
    $("#customui").on("click",function(){
        $(".uicustom").toggle();
        $(".overlay").toggle();
    });
$(".close-icon").on("click",function(){
        $(".uicustom").toggle();
        $(".overlay").toggle();
    });$(".overlay").on("click",function(){
        $(".uicustom").toggle();
        $(this).toggle();
    });
$(".listofimages").on("click",function(){
        $(".dialogbox").toggle();
        $(".overlay_bx").toggle();
    });$(".close-iconx").on("click",function(){
        $(".dialogbox").toggle();
        $(".overlay_bx").toggle();
    });$(".overlay_bx").on("click",function(){
        $(".dialogbox").toggle();
        $(this).toggle();
    });
   /* $(".show-projectlinkview").on("click",function(){
        
       
        $(this).next().slideToggle();
        $(this).parent().addClass("active");
        
    });*/
    $("#animationlist").on("click",function(){
        
        $(".slidemenu").toggle("slide");
    });
    $(".closemenu").on("click",function(){
        
        $(".slidemenu").toggle("slide");
    });
    $(".preview_animation").on("click",function(){
        
        $(".effect").toggleClass("animated");
      
   
    });
    $(document).on("click",".getUrl",function(){
        $(this).prop("contentEditable","true");
    });
    $(".glossarylist").on("click",function(){
       $(".glossarymodal").toggle(); 
        $(".iframesrc").attr("src","glossary/process.php?list"); 
       $(".toggletable").hide(); 
    }); $(".addglossary").on("click",function(){
       //$(".glossarymodal").toggle(); 
       $(".iframesrc").attr("src","glossary/process.php?add"); 
       $(".toggletable").hide(); 
    });
 $(".contentVideo").on("click",function(){
    $(".content-video").show();
    $(".content-video-overlay").show();
}); $(".frameVideo").on("click",function(){
    $(".frame-video").show();
    $(".frame-video-overlay").show();
});
$(".singlechoice").on("click",function(){
    $(".quiz-integrate").show();
    $(".quiz-integrate-overlay").show();
});
    /*On change show editor*/
    $("select").change(function(){
        $(this).find("option:selected").each(function(){
            if($(this).attr("value")=="quiz"){
                $(".hideeditor").show(function(){
                  $("table tr.audiotranscript").hide();
                  $("table tr.htmlcontent").hide();
                    $(".framename").prop("readonly","true");
                    $(".sectionname").prop("readonly","true");
                  $(".framename").val("Quiz");
                  $(".sectionname").val("Learning Activity");
                });
               
            }
            else if($(this).attr("value")=="page"){
                $(".hideeditor").show(function(){
                  $("table tr.audiotranscript").show();
                  $("table tr.htmlcontent").show();
                    $(".framename").removeAttr("disabled","false");
                    $(".sectionname").removeAttr("disabled","false");
                    $(".framename").val("");
                  $(".sectionname").val("");
                });
            }
            else if($(this).attr("value")=="blue"){
                $(".box").not(".blue").hide();
                $(".blue").show();
            }
            else{
                $(".box").hide();
            }
        });
    }).change();
    /*End of editor*/
});
