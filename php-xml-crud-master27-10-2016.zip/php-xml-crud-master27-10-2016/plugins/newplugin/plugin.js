CKEDITOR.plugins.add('newplugin',
{
    init: function (editor) {
        var pluginName = 'newplugin';
        editor.ui.addButton('Newplugin',
            {
                label: 'Add Slide Time',
                command: 'OpenWindow',
                icon: 'http://c.cksource.com/a/1/img/github-top.png'
            });
      var cmd = editor.addCommand('OpenWindow', { exec: showMyDialog });
        
    }
});
function showMyDialog(e) {
 $('#addSlidetime').openModal();
 
}