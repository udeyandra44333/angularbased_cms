<?php
error_reporting(0);
class Process
{
    protected $_xml;
    protected $path;

    public function __construct()
    {
        $this->_xml = simplexml_load_file("data.xml");
    }

    public function getXml()
    {
        return $this->_xml;
    }

    /**
     * @param mixed $path
     */
    public function setPath($path)
    {
        $this->path = $path;
    }

    /**
     * @return mixed
     */
    public function getPath()
    {
        return $this->path;
    }

    public function userlist()
    {

        echo "
        <table border='1' class='highlight'>
            <thead>
                <tr>
                    <td>Page ID</td>
                    <td>Framename</td>
                    <td>Sectioname</td>
                    <td>Audiotranscript</td>
                    <td>Html Content</td>
                    <td>Information</td>
                    <td>Action</td>
                </tr>
            </thead>
        ";

        foreach ($this->_xml as $frame) {
            echo "
            <tr>
                    <td>{$frame->attributes()->id}</td>
                    <td>{$frame->framename}</td>
                    <td>{$frame->sectionname}</td>
                    <td>{$frame->audiotranscript}</td>
                    <td>{$frame->htmlcontent}</td>
                    <td>{$frame->information}</td>
                    <td>
                     <a href='process.php?edit=" . $frame->attributes()->id . "'>Edit</a> |
                     <a href='process.php?delete=" . $frame->attributes()->id . "'>Delete</a>
                    </td>
            </tr>
            ";
        }
        echo "</table>";
    }

    public function filterList($post)
    {
        $xml = $this->_xml->xpath('frame[audiotranscript="' . strtolower($post) . '"]');

        echo "
        <table border='1' class='highlight'>
            <thead>
                <tr>
                      <td>Page ID</td>
                    <td>Framename</td>
                    <td>Sectioname</td>
                    <td>Audiotranscript</td>
                    <td>Html Content</td>
                    <td>Information</td>
                    <td>Action</td>
                </tr>
            </thead>
        ";

        foreach ($xml as $frame) {

            echo "
            <tr>
                    <td>{$frame->attributes()->id}</td>
                    <td>{$frame->framename}</td>
                    <td>{$frame->sectionname}</td>
                    <td>{$frame->audiotranscript}</td>
                    <td>{$frame->htmlcontent}</td>
                    <td>{$frame->information}</td>
            </tr>
            ";
        }
        echo "</table>";
    }

    public function adduser($post)
    {
        if ($post["framename"] != "" &&
            $post["id"] != "" &&
            $post["sectionname"] != "" &&
            $post["audiotranscript"] != "" &&
            $post["htmlcontent"] != "" &&
            $post["information"] != ""
            //$post["user_notes"] != ""
        ) {

            $xml = $this->_xml;
            $frame = $xml->addChild('frame');
            $framename = $frame->addChild("framename", $post["framename"]);
            $sectionname = $frame->addChild("sectionname", $post["sectionname"]);
            $pers = $frame->addChild("audiotranscript", $post["audiotranscript"]);
            $htmlcontent = $frame->addChild("htmlcontent", $post["htmlcontent"]);
            $information = $frame->addChild("information", $post["information"]);
            //$user_notes = $frame->addChild("user_notes", $post["user_notes"]);
            $frame->addAttribute("id", $post["id"]);
            $xml->asXML($this->path);
        }
    }

    public function getUserById($id)
    {
        $frame = $this->_xml->xpath('//frame[@id="' . $id . '"]');
        return $frame[0];
    }

    public function updateUser($post)
    {
        $frame = $this->_xml->xpath('//frame[@id="' . $post['id'] . '"]');

//        $user[0]['id'] = (int) $post["id"];
        $frame[0]->framename = $post["framename"];
        $frame[0]->sectionname = $post["sectionname"];
        $frame[0]->audiotranscript = $post["audiotranscript"];
        $frame[0]->htmlcontent = $post["htmlcontent"];
        $frame[0]->information = $post["information"];
        $this->_xml->asXML($this->path);
    }
}

//Include template
include 'index.php';


//$xml->user[0]->name = "Gayan, Hewa";
//$xml->asXML($completeurl);


//Controller
$param = $_SERVER['QUERY_STRING'];
$arr = explode("=", $param);
if (count($arr) > 1) {
    $param = $arr[0];
}
$path = getcwd()."/data.xml";
$process = new Process();
$process->setPath($path);
if ($param == "list") {
    $process->userlist();
}
if ($param == "add") {
    $post = $_POST;
    $process->adduser($post);
    include 'user.php';
}
if ($param == "filter") {
    $post = $_POST["pers"];
    $process->filterList($post);
}

if ($param == "delete") {
    $id = $arr[1];
    $i = 0;
    foreach ($process->getXml() as $frame){
        if ($frame->attributes()->id == $id){
            unset($process->getXml()->frame[$i]);
            $process->getXml()->asXML($path);
            break;
        }
        $i++;
    }
}

if ($param == "edit") {
    $id = $arr[1];
    $frame = $process->getUserById($id);
    include 'user.php';
}

if ($param == "update") {
    $post = $_POST;
    $process->updateUser($post);
}