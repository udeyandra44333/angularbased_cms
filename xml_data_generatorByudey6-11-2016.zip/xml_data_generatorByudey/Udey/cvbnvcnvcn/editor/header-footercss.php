<?php
if(isset($_POST['css-upload']))
{  
    $headerbg = $_POST['bgcolor1'];
    $headertextcolor = $_POST['headertextcolor'];
    $menubg = $_POST['menuboxbg'];
    $timeline = $_POST['timeline'];
    $timelinecolor = $_POST['timelinecolor'];
    $framesectioncolor = $_POST['framesectioncolor'];
    $audiotranscript = $_POST['audiotranscriptbg'];
    $transcript_title_color = $_POST['transcript_title_color'];
    $transcripttext = $_POST['transcript_text'];
    $iconcolor = $_POST['iconcolor'];
$myfile = fopen('../project/css/header-footer.css', "w") or die("Unable to open file!");
$txt = ".header-footer{background:#".$headerbg.";}.liner{background:#".$headerbg.";}.header-text-color{color:#".$headertextcolor.";}.timeline{background:#".$timeline.";}.timelinecolor{background:#".$timelinecolor.";}.playhead{background:#".$timelinecolor.";}.transcript_title{background:#".$audiotranscript.";color:#".$transcript_title_color."}.transcript_loader{background:#".$audiotranscript.";}.trnscript_text{color:#".$transcripttext.";}.framenames{color:#".$framesectioncolor.";}.sectionnames{color:#".$framesectioncolor.";}.arrow-indicator{color:#".$framesectioncolor.";}.menu-box{color:#".$menubg.";}.icon-color{color:#".$iconcolor."}";
fwrite($myfile, $txt);
//$txt = "<!DOCTYPE html><html><head><title>Page</title></head><body>".$pagecontent."</body></html>";
//fwrite($myfile, $txt);
fclose($myfile);
echo "Hey great you done it";
}
?>