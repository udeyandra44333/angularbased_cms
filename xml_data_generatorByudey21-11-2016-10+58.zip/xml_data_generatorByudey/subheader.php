<?php
$path = getcwd();
//echo $path;
?>

<nav class="height-50">
    <div class="nav-wrapper bluebg">
      <a href="#!" class="brand-logo lightblack">Boffin</a>
      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
      <ul class="right hide-on-med-and-down">
        <li class="showsignout lightblack"><i class="fa fa-user" aria-hidden="true"></i> <?php if(!$userRow['user_name']){echo "Guest"; }else{ echo $userRow['user_name']; } ?>&nbsp;
          <ul>
            <li class="lightblack"><a href="logout.php?logout" class="lightblack">Sign Out</a></li>
            </ul>
          </li>
        
      </ul>
      <ul class="side-nav" id="mobile-demo">
         <li><a href="collapsible.html"><i class="fa fa-user" aria-hidden="true"></i> <?php if(!$userRow['user_name']){echo "Guest"; }else{ $userRow['user_name']; } ?>&nbsp;</a></li>
        <li class="black-text"><a href="logout.php?logout">Sign Out</a></li>
      </ul>
    </div>
  </nav>