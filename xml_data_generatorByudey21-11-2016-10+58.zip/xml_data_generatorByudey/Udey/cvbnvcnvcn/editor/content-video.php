<?php
$valid_formats = array("mp4");
$max_file_size = 10000000; // 10 MB
$path = "../project/content-video/"; // Upload directory
$count = 0;
error_reporting(0);
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST"){
	// Loop $_FILES to execute all files
	foreach ($_FILES['cvideos']['name'] as $fs => $name) {     
	    if ($_FILES['cvideos']['error'][$fs] == 4) {
	        continue; // Skip file if any error found
	    }	       
	    if ($_FILES['cvideos']['error'][$fs] == 0) {	           
	       if ($_FILES['cvideos']['size'][$fs] > $max_file_size) {
	            $message[] = "$name is too large!.";
	            continue; // Skip large files
	        }
			elseif( ! in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) ){
				$message[] = "$name is not a valid format";
				continue; // Skip invalid file formats
			}
	       else{ // No error found! Move uploaded files 
	            if(move_uploaded_file($_FILES["cvideos"]["tmp_name"][$fs], $path.$name)) {
	            	$count++; // Number of successfully uploaded files
	            }
	       }
	    }
	}
}
?>

<style type="text/css">
a{ text-decoration: none; color: #333}
h1{ font-size: 1.9em; margin: 10px 0}
p{ margin: 8px 0}
*{
	margin: 0;
	padding: 0;
	box-sizing: border-box;
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-font-smoothing: antialiased;
	-moz-font-smoothing: antialiased;
	-o-font-smoothing: antialiased;
	font-smoothing: antialiased;
	text-rendering: optimizeLegibility;
}

.wrap{
	width: 500px;
	/*margin: 15px auto;*/
	padding: 20px 25px;
	background: white;
	border: 2px solid #DBDBDB;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	border-radius: 5px;
	overflow: hidden;
	text-align: center;
        height: 232px;
}
.status {
    /* display: none; */
    padding: 5px 35px 5px 14px;
    margin: 3px 0;
    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
    color: #468847;
    background-color: #dff0d8;
    border-color: #d6e9c6;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
}
input[type="submit"] {
	cursor:pointer;
	width:100%;
	border:none;
	background:#991D57;
	background-image:linear-gradient(bottom, #8C1C50 0%, #991D57 52%);
	background-image:-moz-linear-gradient(bottom, #8C1C50 0%, #991D57 52%);
	background-image:-webkit-linear-gradient(bottom, #8C1C50 0%, #991D57 52%);
	color:#FFF;
	font-weight: bold;
	margin: 20px 0;
	padding: 10px;
	border-radius:5px;
}
input[type="submit"]:hover {
	background-image:linear-gradient(bottom, #9C215A 0%, #A82767 52%);
	background-image:-moz-linear-gradient(bottom, #9C215A 0%, #A82767 52%);
	background-image:-webkit-linear-gradient(bottom, #9C215A 0%, #A82767 52%);
	-webkit-transition:background 0.3s ease-in-out;
	-moz-transition:background 0.3s ease-in-out;
	transition:background-color 0.3s ease-in-out;
}
input[type="submit"]:active {
	box-shadow:inset 0 1px 3px rgba(0,0,0,0.5);
}
    .fieldset{    height: 176px;}
</style>

	<div class="wrap">
			<!-- Multiple file upload html form-->
		<form action="" method="post" enctype="multipart/form-data">
        <fieldset class="fieldset">
             <legend>Content Video File:</legend>
			<input type="file" name="cvideos[]" multiple="multiple" accept="video/*">
			<input type="submit" value="Upload">
            	<?php
		# error messages
		if (isset($message)) {
			foreach ($message as $msg) {
				printf("<p class='status'>%s</p></ br>\n", $msg);
			}
		}
		# success message
		if($count !=0){
			printf("<p class='status'>%d files added successfully!</p>\n", $count);
		}
		?>
            </fieldset>
           
		</form>
</div>
