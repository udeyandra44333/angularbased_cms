<div class="col s12 m12 l12 padding-0">
<div class="col s12 m2 l2 padding-0 left-panel">
 <aside class="col s12 m12 l12 padding-0 ">
<div class="col s12 m12 l12 padding-0 white-text">
<h5 align="center">Boffin</h5>    
</div>
<div class="col s12 m12 l12 margin-top-30">
<div class="col s12 m4 l4 padding-0">
   <img src="images/icon.png" class="profileimg border-item" /> 
</div>
<div class="col s12 m8 l8 white-text">
<div class="col s12 m12 l12 padding-0">
<span class="welcome">Welcome,</span>
</div>
<div class="col s12 m12 l12 padding-0">
<a href="#" class="profile username"><?php if(!$userRow['user_name']){echo "Guest"; }else{ echo $userRow['user_name']; } ?></a>    
</div>
</div>
     </div>
<div class="col s12 m12 l12 margin-top-12">
  <h6  class="white-text"><i class="fa fa-list caretini-fontio listino" aria-hidden="true"></i> List of projects</h6>	   
</div>	
<?php
include("projectlist.php");
?>

		
	</aside>   
    </div>
<div class="col s12 m10 l10 loadeditor padding-0">
<?php include("subheader.php"); ?>
<h4>Start your project</h4>
<div class="col s12 m4 l4 text-box">
<form action="createfolder.php" name="createProject" method="post"  class="go_to_next">
    <label id="hint"></label>
  <input type="text" name="project" placeholder="Project Name" class="gettext" class="required"  />
   <input type="submit" value="Create Folder"  class="create-project" /> 

</form>
</div>
<h4 class="successMessage center">Project created successfully</h4>
   
    <div class="col s12 m12 l12 padding-0 animated fadeInUp template-box">
         <label class="errormsg"></label>
       <iframe width="50%" height="25" frameborder="0" scrolling="no" name="templatecreate" id="templatecreate"></iframe> 
    <form action="createtemplate.php" name="createtemplate" method="post" class="choose_template"  target="templatecreate">
        <div class="col s12 m12 l12 padding-0 animated fadeIn">
        <div class="col s12 m6 l6"><h4>Choose your template</h4></div>
          <div class="col s12 m3 l3"><input type="submit" class="btn right next-page" value="Next>>" /></div>
        <input type="hidden" name="getthefolder" class="texttoextrct" value="" />
             <input name="editorname" type="hidden" value="editor" />
        </div>
    <div class="col s12">
         <div class="col s12 m4 l4 margin-7">
   <div class="col s12 m12 l12 theme padding-0">
        <input class="with-gap" name="templatename" type="radio" value="project" id="test1"/>
       
      <label for="test1">Blueish</label>
       
    <img class="img-responsive" src="images/thumbnail/1.png" />   
    </div>
    </div>    
    <div class="col s12 m4 l4 margin-7">
   <div class="col s12 m12 l12 theme padding-0">
        <input class="with-gap" name="templatename" type="radio" value="project" id="test2"/>
       
      <label for="test2">Blueish</label>
       
    <img class="img-responsive" src="images/thumbnail/1.png" />   
    </div>
    </div> 
        </div>
  
 


 
  
</form>
</div>
    <?php include("footer.php") ?>
</div>

</div>
