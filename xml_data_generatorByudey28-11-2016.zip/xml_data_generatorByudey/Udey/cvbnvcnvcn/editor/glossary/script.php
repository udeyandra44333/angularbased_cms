<script src="../../../../js/jquery-3.1.1.js"></script>
    <script src="../ckeditor.js"></script>
	<script src="../js/editorsnis.js"></script>
<link rel="stylesheet" href="../css/ckeditor.css" />
<link rel="stylesheet" href="../../../../css/myauthor.css" />
<link rel="stylesheet" href="../../../../css/animate.css" />
<link rel="stylesheet" type="text/css" href="../css/editor.css" />
<link rel="stylesheet" type="text/css" href="../../../../css/materialize.css" />