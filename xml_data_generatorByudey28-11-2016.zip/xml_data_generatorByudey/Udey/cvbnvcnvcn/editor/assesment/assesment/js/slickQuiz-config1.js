var quizJSON = {
    "info": {
        "name":    "<b>Learning Activity </b>",
        "main":    "<p><b>Choose the best response and click/tap the Submit button.</b></p>",
        "results": "<h3>Finished</h3><h2>Congratulations you have completed the test.</h2>",
        "level1":  "Excellent",
        "level2":  "Brilliant",
        "level3":  "Good",
        "level4":  "Average",
        "level5":  "Poor" // no comma here
    },
    "questions": [
        { 
        "q":" 
    sdfsdfsd",
            "a": [
                {"option": "dsdf",      "correct": true},
                {"option": "sdfsdf",     "correct": false},
                {"option": "sf",      "correct": true},
                {"option": "vnbmmnm",     "correct": false},
                {"option": "hjghj",     "correct": true}
            ],
            "correct": "<p><span>fsfsf</span></p>",
            "incorrect": "<p>dfsdfsf</p>" 
        }
       
      
    ]
};