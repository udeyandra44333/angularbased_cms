<?php
if(isset($_POST['btn-upload']))
{  
    $pageid = $_POST['pageid'];
    $pagecontent = $_POST['framecontent'];
$myfile = fopen('../project/page'.$pageid.'.html', "w") or die("Unable to open file!");
$txt = "<!DOCTYPE html><html><head><title>Page</title><script>$(document).ready(function(){
        $('#audio-slideshow').udSynch();});</script></head><body>".$pagecontent."</body></html>";
fwrite($myfile, $txt);
//$txt = "<!DOCTYPE html><html><head><title>Page</title></head><body>".$pagecontent."</body></html>";
//fwrite($myfile, $txt);
fclose($myfile);
echo "Hey great you done it";
}
if(isset($_POST['non-audio']))
{  
    $no_audio_pageid = $_POST['no_audio_pageid'];
    $no_audio_pagecontent = $_POST['no_audio_framecontent'];
$no_audio_myfile = fopen('../project/page'.$no_audio_pageid.'.html', "w") or die("Unable to open file!");
$no_audio_txt = "<!DOCTYPE html><html><head><title>Page</title></head><body>".$no_audio_pagecontent."</body></html>";
fwrite($no_audio_myfile, $no_audio_txt);
//$txt = "<!DOCTYPE html><html><head><title>Page</title></head><body>".$pagecontent."</body></html>";
//fwrite($myfile, $txt);
fclose($no_audio_myfile);
echo "Hey great you done it no_audio_file";
}
?>