
<?php if (!isset($id) || $id == "") :?>
<h3>Add New Record</h3>
<form method="POST" action="process.php?add">
    <table>
        <tr>
            <td>Page ID</td>
            <td><input type='text' name='id'/></td>
        </tr>
        <tr>
            <td>Frame Name</td>
            <td><input type="text"  name='framename' /></td>
        </tr>
        <tr>
            <td>Section Name</td>
            <td><input type="text" name='sectionname' /></td>
        </tr>
        <tr>
            <td>Audio Transcript</td>
            <td><textarea  id="editor1" name='audiotranscript' ></textarea></td>
        </tr>
        <tr>
            <td>Html Content</td>
            <td><textarea  id="editor2" name='htmlcontent' ></textarea></td>
        </tr>
        <tr>
            <td>Information Text
            </td>
            <td><textarea  id="editor3" name='information' ></textarea></td>
        </tr>
       
    </table>
    <input type="submit" value="Save"/>
</form>
<?php else:?>

    <h3>Update the existing user :</h3>
    <form method="POST" action="process.php?update">
        <table>
            <tr>

                <td><input type='hidden' name='id' value='<?php echo $frame->attributes()->id;?>'/></td>
            </tr>
            <tr>
                <td>Name</td>
                <td><input type="text" name='framename' value="<?php echo $frame->framename;?>" /></td>
            </tr>
            <tr>
                <td>Job</td>
                <td><input type="text" name='sectionname' value="<?php echo $frame->sectionname;?>" /></td>
            </tr>
            <tr>
                <td>Personality</td>
                <td><textarea  id="editor1" name='audiotranscript' ><?php echo $frame->audiotranscript;?></textarea></td>
            </tr>
            <tr>
                <td>Salary</td>
                <td><textarea  id="editor2" name='htmlcontent' ><?php echo $frame->htmlcontent;?></textarea></td>
            </tr>
            <tr>
                <td>Email
                </td>
                <td><textarea  id="editor3" name='information' ><?php echo $frame->information; ?></textarea></td>
            </tr>
          
        </table>
        <input type="submit" value="Save"/>
    </form>
<?php endif;?>
<script>
	initSample();
</script>