var projectname;
function validateCreateproject()
{
      var x = document.forms["createProject"]["project"].value;
    if (x == null || x == "") {
        $("#hint").show().text("Please add your project name")
        return false;
    }
    else{
       setTimeout(function(){
           $(".go_to_next").hide();
           $(".template-box").show();
           $(".successMessage").show();
       },100);  
    }
}

$(document).ready(function(){
    $('.collapsible').collapsible();
    $(".modalopen").on("click",function(){
        $("#audio-upload").openModal();
    });
$( ".gettext" ).focus(function() {
  $("#hint").hide();
});$( ".with-gap" ).focus(function() {
  $(".errormsg").hide();
});
    $('.go_to_next').submit(function (event) {
        validateCreateproject();
        projectname =  $(".gettext").val();
        $(".texttoextrct").val(projectname);
        $(".foldername_p").val(projectname);
        event.preventDefault();
 return false;
});
  $(".choose_template").submit(function(event){
      setTimeout(function(){
         location.reload();
      },2000);
    
  });  
    
   /* $(".show-projectlinkview").on("click",function(){
        
       
        $(this).next().slideToggle();
        $(this).parent().addClass("active");
        
    });*/
});