<?php
$path = getcwd();
//echo $path;
?>
<div class="row">
<div class="col m12 l12 s12 padding-0">

<nav>
    <div class="nav-wrapper header-bg">
      <a href="#!" class="brand-logo">Logo</a>
      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
      <ul class="right hide-on-med-and-down">
        <li>Hi' <?php echo $userRow['user_name']; ?>&nbsp;<a href="logout.php?logout">Sign Out</a></li>
      </ul>
      <ul class="side-nav" id="mobile-demo">
         <li><a href="collapsible.html">Hi' <?php echo $userRow['user_name']; ?>&nbsp;</a></li>
        <li class="black-text"><a href="logout.php?logout">Sign Out</a></li>
      </ul>
    </div>
  </nav>