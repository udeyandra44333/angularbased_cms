<?php
session_start();
include_once '../../../dbconnect.php';

if(!isset($_SESSION['user']))
{
	header("Location: ../../../index.php");
}
$res=mysql_query("SELECT * FROM users WHERE user_id=".$_SESSION['user']);
$userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>XML CRUD APP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <script src="js/jquery-3.1.1.js"></script>
    <script src="ckeditor.js"></script>
	<script src="js/editorsnis.js"></script>
      <!--Let browser know website is optimized for mobile-->
    <script src="../../../js/myauthor.js"></script>
<link rel="stylesheet" href="css/ckeditor.css">
<link rel="stylesheet" href="../../../css/myauthor.css">
<link rel="stylesheet" type="text/css" href="css/editor.css" />
<link rel="stylesheet" type="text/css" href="css/materialize.css" />

</head>
<body>
    <?php
    include_once '../../../subheader.php';
    ?>
    <div class="col s12 m12 l12 padding-0 margin-top-60">
    <div class="col s12 m12 l12 padding-0">
<div class="col s12 m2 l2 padding-0">
 <aside>
<h6 align="center">List of projects</h6>		
<?php
include("../../../projectlist.php");
?>

		
	</aside>   
</div>
<div class="col s12 m10 l10 loadeditor padding-0">
   
    <!--<ul>
        <li><a href="process.php?list">List Pages</a></li>
        <li><a href="process.php?add">Add Pages</a></li>
    </ul>  -->
     <nav>
    <div class="nav-wrapper margin-top-4">
      <ul id="nav-mobile" class="left hide-on-med-and-down">
           <?php
   echo "<li><a href='http://$domain' >Go Back</a></li>";
       ?>
        <li><a href="process.php?list">Page List</a></li>
        <li><a href="process.php?add">Add Page</a></li>
        <li><a href="#">Upload Images</a></li>
        <li><a href="#">Upload Videos</a></li>
        <li><?php echo "<a href='http://$domain/$userfoldername/' target='_blank'>Preview</a>" ?></li>
      </ul>
    </div>
  </nav>
      <script type="text/javascript" src="js/materialize.min.js"></script>
</body>
 

</html>







