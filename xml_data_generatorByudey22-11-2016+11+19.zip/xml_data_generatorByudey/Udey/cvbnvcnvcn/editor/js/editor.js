$(document).ready(function(){
$(".list").on("click",function(){
   $(".loadeditor").load("../editor/process.php?list"); 
    alert(1);
});
});