<?php
session_start();
include_once '../../../dbconnect.php';

if(!isset($_SESSION['user']))
{
	header("Location: ../../../index.php");
}
$res=mysql_query("SELECT * FROM users WHERE user_id=".$_SESSION['user']);
$userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>XML CRUD APP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <script src="js/jquery-3.1.1.js"></script>
    <script src="ckeditor.js"></script>
	<script src="js/editorsnis.js"></script>
      <!--Let browser know website is optimized for mobile-->
    <script src="../../../js/myauthor.js"></script>
    <script src="js/jscolor.js"></script>
<link rel="stylesheet" href="css/ckeditor.css" />
<link rel="stylesheet" href="../../../css/myauthor.css" />
<link rel="stylesheet" href="../../../css/animate.css" />
    <link rel="stylesheet" type="text/css" href="../../../css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/editor.css" />
<link rel="stylesheet" type="text/css" href="css/materialize.css" />
<style>
.margin-top-60 {
    margin-top: -126px;
}    
</style>
</head>
<body>
    <div class="overlay">
    
</div> 
<div class="overlay_bx">
    
</div>
<div class="dialogbox">
    <div class="close-iconx btn">Close</div>
<div class="imaging">
   <?php include("list_of_images.php");
    ?> 
</div>
</div>
<?php
     include_once '../../../animationlist.php';
    ?>
<div class="row">    
    <div class="col s12 m12 l12 padding-0">
    <div class="col s12 m12 l12 padding-0">
<div class="col s12 m2 l2 padding-0">
 <aside class="col s12 m12 l12 padding-0">
<div class="col s12 m12 l12 padding-0 white-text">
<h5 align="center">Boffin</h5>    
</div>
<div class="col s12 m12 l12 margin-top-30">
<div class="col s12 m4 l4 padding-0">
   <img src="../../../images/icon.png" class="profileimg border-item" /> 
</div>
<div class="col s12 m8 l8 white-text">
<div class="col s12 m12 l12 padding-0">
<span class="welcome">Welcome,</span>
</div>
<div class="col s12 m12 l12 padding-0">
<a href="#" class="profile username"><?php if(!$userRow['user_name']){echo "Guest"; }else{ echo $userRow['user_name']; } ?></a>    
</div>
</div>
     </div>
<div class="col s12 m12 l12 margin-top-12">
  <h6  class="white-text"><i class="fa fa-list caretini-fontio listino" aria-hidden="true"></i> List of projects</h6>	   
</div>		
<?php
include("../../../projectlist.php");
?>

		
	</aside>   
</div>
<div class="col s12 m10 l10 loadeditor padding-0">

<?php
    include_once '../../../subheader.php';
    /*Need to change during live*/
    $url = $_SERVER['REQUEST_URI'];
$tokens = explode('/', $url);
$previewspec = $tokens[sizeof($tokens)-3];
    ?>
    <!--<ul>
        <li><a href="process.php?list">List Pages</a></li>
        <li><a href="process.php?add">Add Pages</a></li>
    </ul>  -->
     <nav class="height-50">
    <div class="nav-wrapper brandingbg1">
      <ul id="nav-mobile" class="left hide-on-med-and-down margin-top-21 tablistmgr">
           <?php
   echo "<li class='marging-top-7'><a href='http://$domain' >Go Back</a></li>";
       ?>
        <li class="marging-top-7"><a href="process.php?list">Page List</a></li>
        <li class="marging-top-7"><a href="process.php?add">Add Page</a></li>
        <li class="marging-top-7"><a href="#" id="customui">Customize UI</a></li>
        <li class="glsry marging-top-7"><a href="#">Create Glossary</a>
          <ul class="brandingbg1 marging-top-7">
            <li><a href="#" class="coursenmoduleTitle nestedanchor">Course Title</a></li>
            <li><a href="#" class="glossarylist nestedanchor">Show glossary</a></li>
              <li><a href="#" class="addglossary nestedanchor">Create glossary</a></li>
            </ul>
          </li>
        <li class="marging-top-7"><a href="#" class="listofimages">Show Images</a></li>
        <li class="marging-top-7"><a href="#" id="animationlist">Animation list</a></li>
        <li class="glsry marging-top-7"><a href="#" id="quizes" >Features</a>
          <ul class="brandingbg1 marging-top-7">
              <li><a href="#" class="tabfeature nestedanchor">Tab Feature</a></li>
            <li><a href="#" class="singlechoice nestedanchor">Quiz</a></li>
              <li><a href="#" class="assesment nestedanchor">Assesment</a></li>
            </ul>
          </li>
        <li class="glsry marging-top-7"><a href="#" >Video</a>
          <ul class="brandingbg1 marging-top-7">
            <li><a href="#" class="contentVideo nestedanchor">Content Video</a></li>
            <li><a href="#" class="frameVideo nestedanchor">Frame Video</a></li>
            </ul>
          </li>
        <li class="marging-top-7"><?php echo "<a href='http://$domain/$userfoldername/$previewspec/project' target='_blank'>Preview</a>" ?></li>
      </ul>
    </div>
  </nav>

     <div class="uicustom">
    <div class="headersection">
         <h5 class="modalheader">Header</h5>
        <div class="close-icon btn">Close</div>
         </div>
    <div class="uicust-body">
<div class="col s12 m12 l12">
     <div class="col s12 m6 l6">
         <div class="col s12 m12 l12">
        <form action="uploadlogo.php" method="POST" enctype="multipart/form-data">
        <fieldset>
<legend>Logo File:</legend>
         <input type="file" name="image" />
         <input type="submit"/>
        </fieldset>
      </form>
    </div>
    </div>  
    <div class="col s12 m6 l6">
    <div class="col s12 m12 l12">
        <form action="homescreen.php" method="POST" enctype="multipart/form-data">
        <fieldset>
<legend>Homescreen File:</legend>
         <input type="file" name="image" />
         <input type="submit"/>
        </fieldset>
      </form>
    </div>   
    </div>
</div>
<form action="header-footercss.php" method="post" enctype="multipart/form-data">
        <div class="col s12 m6 l6">
           <div class="col s12 m12 l12">
        <fieldset>
        <legend>Player Header/Footer</legend>
           <label>Header/Footer Bg
         <input class="jscolor" name="bgcolor1" value="transparent">
            </label> 
        <label>Header/Footer Text Color
         <input class="jscolor" name="headertextcolor" value="transparent">
            </label>
        <label>Frame/Section name color
         <input class="jscolor" name="framesectioncolor" value="transparent">
            </label>
            </fieldset>
        </div>
        <div class="col s12 m12 l12">
        <fieldset>
         <legend>Timeline</legend>
              <label>Timeline color
         <input class="jscolor" name="timeline" value="transparent">
            </label>
        <label>Progressbar color
         <input class="jscolor" name="timelinecolor" value="transparent">
            </label>
            </fieldset>
        </div>   
        <div class="col s12 m12 l12">
        <fieldset>
         <legend>Frame Container</legend>
              <label>Add Background
         <input class="jscolor" name="framebg" value="transparent">
            </label>  
        <label>Add frame text color
         <input class="jscolor" name="frametext" value="transparent">
            </label>
            </fieldset>
        </div>  
        <div class="col s12 m12 l12">
        <fieldset>
         <legend>Glossary</legend>
              <label>Add Background
         <input class="jscolor" name="glossarybg" value="transparent">
            </label>  
        <label>Add text color
         <input class="jscolor" name="glossarytext" value="transparent">
            </label>
            </fieldset>
        </div>
        </div>
        <div class="col s12 m6 l6">
              <div class="col s12 m12 l12">
        <fieldset>
        <legend>Menu Background</legend>
            <label>
            Menu Bg
            <input class="jscolor" name="menuboxbg" value="transparent" />
            </label> 
            <label>
            Menu icons color
            <input class="jscolor" name="iconcolor" value="transparent" />
            </label> 
            <label>
            Dropdown Menu Item Text color
            <input class="jscolor" name="menuitemtext" value="transparent" />
            </label>
            <label>
            Dropdown Menu Title text
            <input class="jscolor" name="title_menu_text" value="transparent" />
            </label>
            <label>
            Dropdown Menu Title BG
            <input class="jscolor" name="title_menu_bg" value="transparent" />
            </label>
            </fieldset>       
        </div>
        <div class="col s12 m12 l12">
        <fieldset>
            <legend>Transcript</legend>
            <label>Transcript Background
         <input class="jscolor" name="audiotranscriptbg" value="transparent">
            </label>
        <label>
            Transcript Title Text Color
            <input class="jscolor" name="transcript_title_color" value="transparent">
            </label>
        <label>
            Transcript Text
            <input class="jscolor" name="transcript_text" value="transparent">
            </label>
            </fieldset>
            </div>
        </div>
    <div class="col s12 m12 l12">
    <input type="submit" name="css-upload" />           
    </div>       
      </form>
         </div>
    </div>
<div class="glossarymodal">
<iframe src="glossary/process.php?add" width="100%" height="100%" class="iframesrc" frameborder="0" scrolling="no"></iframe>  
    
</div>
<div class="content-video white">
<h5>Content Videos</h5>
    <div class="row">
    <div class="col s12 m12 l12">
    <?php include("content-video.php"); ?>    
    </div>
    </div>
</div>
<div class="content-video-overlay"></div>
<div class="frame-video white">
<h5>frame Videos</h5>
    <div class="row">
    <div class="col s12 m12 l12">
    <?php include("frame-video.php"); ?>    
    </div>
    </div>
</div>

<div class="frame-video-overlay"></div>
<div class="quiz-integrate white">
<h5>Single choice Quiz</h5>
<div class="row">
<div class="col s12 m12 l12">
    <div class="col s12 m12 l12 singlechoice">
    <?php
    include("quizes/singleandmultiplechoice.php");
    ?>
    </div>
    <div class="col s12 m12 l12 dragndrop">
    <h6>Create drag and drop</h6>
    <div class="col s12 m12 l12">
        <form action="quizes/dragndrop.php" method="post" enctype="multipart/form-data">
        <input type="text" name="pageid" placeholder="Enter your PageID" />
        <input type="text" name="itemrange" placeholder="Define number of items" />
        <textarea name="draggableQuest">Question1,Question2 and so on</textarea>
        <textarea name="draggableData">Answer1,Answer2 and so on</textarea>
            <input type="submit" name="dragndrop" value="Create" class="btn large" />
        </form>
    </div>
    </div>
</div>    
</div>    
</div>
<div class="quiz-integrate-overlay">
    
</div>
<div class="integrate-tabfeature white">
<h6>Tab Feature</h6>
<div class="col s12 m12 l12">
<form action="tabfeature/tabFeature.php" method="post" enctype="multipart/form-data">
<input type="text" placeholder="Page ID" name="pageid" />
    <input type="text" placeholder="Tab1" name="tab1" />
    <input type="text" placeholder="Tab2" name="tab2" />
    <input type="text" placeholder="Tab3" name="tab3" />
    <input type="text" placeholder="Tab4" name="tab4" />
    <textarea id="editor1" name="tab_one_content"></textarea>
    <textarea id="editor2" name="tab_two_content"></textarea>
    <textarea id="editor3" name="tab_three_content"></textarea>
    <textarea id="editor4" name="tab_four_content"></textarea>
    <input type="submit" name="createtabs" value="Create Tab" />
</form>   
</div>
</div>
    <div class="tabfeature-overlay">
    
    </div>
<div class="assesmentCreator white">
<h6>Create your assesment</h6>
<div class="col s12 m12 l12">
<?php include("assesment/singleandmultiplechoice.php"); ?>   
</div>
</div>
<div class="assesmentCreatorOverlay">
</div>
<div class="coursenmodule white">
<h6>Add Course and Module Title</h6>
<div class="col s12 m12 l12">
<form action="coursenmoduleTitle.php" method="post" enctype="multipart/form-data">
    <input type="text" name="courseTitle" placeholder="Course Title" />    
    <input type="text" name="moduleTitle" placeholder="Module Title" /> 
    <input type="submit" name="coursenmoduleTitle" value="Create" />
</form>    
</div>
</div>
<div class="coursenmoduleOverlay">
    
</div>
    <script>
	initSample();
</script>
     <script type="text/javascript" src="js/materialize.min.js"></script>
</body>
 

</html>







