<?php

?>
<html>
<head>
    <meta charset="utf-8">
    <title>XML CRUD APP</title>
    <script src="ckeditor.js"></script>
	<script src="js/editorsnis.js"></script>
	<link rel="stylesheet" href="css/ckeditor.css">
    <link rel="stylesheet" type="text/css" href="css/editor.css" />


</head>
<body>
    <ul>
        <li><a href="process.php?list">List All Users</a></li>
        <li>
            <form method="POST" action="process.php?filter">
                <input type="text" value='' name="pers"/>
                <input type="submit" value="Filter"/>
            </form>
        </li>
        <li><a href="process.php?add">Add User</a></li>
    </ul>
  
</body>
 

</html>







